package com.oracle.demo.domain.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.oracle.demo.domain.Employee;
import com.oracle.demo.repo.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository entityRepository;

	public Employee create(Employee entity) {
		final Employee employee = entityRepository.save(entity);
		return employee;
	}
}
