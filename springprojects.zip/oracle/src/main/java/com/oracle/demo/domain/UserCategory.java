package com.oracle.demo.domain;

public enum UserCategory {
	Admin, User
}
