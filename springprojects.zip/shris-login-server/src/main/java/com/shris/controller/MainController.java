package com.shris.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.shris.domain.ClientUser;
import com.shris.security.CustomUserPrincipal;

@Controller
public class MainController {

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public @ResponseBody String defaultPage(ModelMap map) {
		return "{\"message\":\"Login First\"}";
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login() {
		return "login";
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public @ResponseBody String logout() {
		SecurityContextHolder.clearContext();
		return "{\"message\":\"Logout Success\"}";
	}

	@RequestMapping(value = "/logoutSuccess", method = RequestMethod.GET)
	public @ResponseBody String logoutSuccess() {
		SecurityContextHolder.clearContext();
		return "logout";
	}

	@RequestMapping(value = "/loginFirst")
	public @ResponseBody String loginFirst() {
		return "{\"message\":\"login First\"}";
	}

	@RequestMapping(value = "/accessdenied")
	public @ResponseBody String loginerror(HttpServletRequest request, HttpServletResponse response) {
		response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		return "{\"message\":\"Access Denied\"}";
	}

	@RequestMapping(value = "/loginSuccess")
	public @ResponseBody String loginSuccess() {
		return "{\"message\":\"login success\"}";
	}

	@RequestMapping(value = "/loginFailure")
	public @ResponseBody String loginFailure(HttpServletRequest request, HttpServletResponse response) {
		response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		return "{\"message\":\"Invalid Credentials\"}";
	}

	@RequestMapping(value = "/isLoggedIn")
	public @ResponseBody String isLoggedIn() {
		return "{\"message\":\"yes\"}";
	}

	@RequestMapping(value = "/getCurrentUser")
	public @ResponseBody ClientUser getCurrentUser() {

		CustomUserPrincipal userPrincipal = (CustomUserPrincipal) SecurityContextHolder.getContext().getAuthentication()
				.getPrincipal();
		ClientUser clientUser = userPrincipal.getClientUser();

		return clientUser;
	}

}
