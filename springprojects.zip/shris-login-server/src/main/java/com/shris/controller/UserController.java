package com.shris.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.shris.domain.User;
import com.shris.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@RequestMapping(value = "/", method = RequestMethod.POST)
	public String registration(@RequestBody User user) {
		logger.info("User Object" + user);
		userService.save(user);
		return "registration success";
	}

	@RequestMapping(value = "/", method = RequestMethod.PUT)
	public String update(@RequestBody User user) {
		logger.info("User Object" + user);
		userService.update(user);
		return "updated successfully";
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public String delete(@PathVariable String id) {
		logger.info("User Id" + id);
		userService.delete(id);
		return "deleted succesfully";
	}

	@RequestMapping(value = "/")
	public List<User> getUserTag() {
		List<User> returnuser = userService.getUsers();
		return returnuser;
	}

}
