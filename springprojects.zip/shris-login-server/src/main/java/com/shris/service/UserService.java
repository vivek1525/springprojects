package com.shris.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.shris.domain.User;
import com.shris.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private UserRepository userRepository;

	public String save(User user) {

		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		user.setPassword(passwordEncoder.encode(user.getPassword()));

		mongoTemplate.save(user);
		return "success";
	}

	public String update(User user) {

		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(user.getId()));
		User existingUser = mongoTemplate.findOne(query, User.class);
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		if (existingUser == null) {
			return "user does not exist";
		}
		userRepository.save(user);
		return "success";
	}

	public List<User> getUsers() {

		List<User> usersList = userRepository.findAll();

		return usersList;

	}

	public void delete(String id) {

		Query query = new Query();
		query.addCriteria(Criteria.where("_id").is(id));
		User existingUser = mongoTemplate.findOne(query, User.class);
		if (existingUser == null) {
			return;
		}
		mongoTemplate.remove(query, User.class);

	}
}
