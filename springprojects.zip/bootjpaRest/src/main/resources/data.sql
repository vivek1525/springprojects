insert into user values (101,27,'vivek.korepu@gmail.com','vivek');
insert into user values(102,24,'vikas1603@gmail.com','vikas');
insert into user values(103,50,'raju@gmail.com','raju');
insert into user values(104,42,'laxmi@gmail.com','laxmi');