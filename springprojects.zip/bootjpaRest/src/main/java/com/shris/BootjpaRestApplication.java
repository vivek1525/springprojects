package com.shris;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.shris.customizer.CustomRestTemplateCustomizer;

@SpringBootApplication
public class BootjpaRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootjpaRestApplication.class, args);
	}

	@Bean
	public CustomRestTemplateCustomizer customRestTemplateCustomizer() {
		return new CustomRestTemplateCustomizer();
	}

}
