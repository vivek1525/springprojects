package com.shris.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;

import com.shris.domain.User;

@RepositoryRestResource(collectionResourceRel = "user", path = "user")
public interface UserRepository extends JpaRepository<User, Integer> {
	@RestResource(path="/fetchbyName")
	List<User> findByName(@Param("name") String name);// http://localhost:8080/user/search/fetchbyName?name=vikas

	List<User> findByAgeLessThan(@Param("age") int age);// http://localhost:8080/user/search/findByAgeLessThan?age=25
}
