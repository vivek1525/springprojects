package com.shris.spring.generator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import com.fasterxml.jackson.core.JsonParser.Feature;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.shris.spring.generator.model.GeneratorModel;

public class ModelParser {
	
	public static GeneratorModel parse(final String args[]) throws FileNotFoundException {

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		mapper.configure(DeserializationFeature.FAIL_ON_MISSING_CREATOR_PROPERTIES, false);
		mapper.configure(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES, false);
		mapper.getFactory().enable(Feature.ALLOW_COMMENTS);
		mapper.getFactory().enable(Feature.IGNORE_UNDEFINED);
		
		String fileNamePath = "input" + File.separator + "vinod-demo.json";
		InputStream inputStream = null;
		
		if(args != null && args.length>0)
		{
			fileNamePath = args[0];
			File initialFile = new File(fileNamePath);
		    inputStream = new FileInputStream(initialFile);
		}else
		{
			inputStream = Application.class.getClassLoader().getResourceAsStream(fileNamePath);
		}
		
		GeneratorModel genModel = null;
		//JSON from URL to Object
		try {
			genModel = mapper.readValue(inputStream, GeneratorModel.class);
			
		}catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		
		return genModel;
	}
}
