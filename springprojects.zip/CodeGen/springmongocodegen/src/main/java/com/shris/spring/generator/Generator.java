package com.shris.spring.generator;

public interface Generator {
	public void generate(final Parameters params) throws Exception;
}
