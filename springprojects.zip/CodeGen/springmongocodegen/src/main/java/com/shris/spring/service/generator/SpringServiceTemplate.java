package com.shris.spring.service.generator;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.shris.spring.generator.Template;

public class SpringServiceTemplate implements Template{
	
	public Reader getReader() {
		final InputStream is = getClass().getClassLoader().getResourceAsStream("ServiceTemplate.mustache");
		final BufferedReader br = new BufferedReader(new InputStreamReader(is));
		return br;
	}
	
	public String getTemplate() {

		StringBuilder sb = new StringBuilder();
		sb.append("package {{packageName}}.service;");
		sb.append("\n");
		sb.append("import java.util.List;");
		sb.append("\n");
		sb.append("import java.util.UUID;");
		sb.append("\n");
		sb.append("import org.springframework.beans.factory.annotation.Autowired;");
		sb.append("\n");
		sb.append("import org.springframework.data.domain.Page;");
		sb.append("\n");
		sb.append("import org.springframework.data.domain.PageRequest;");
		sb.append("\n");
		sb.append("import org.springframework.data.mongodb.core.MongoTemplate;");
		sb.append("\n");
		sb.append("import org.springframework.data.mongodb.core.query.Query;");
		sb.append("\n");
		sb.append("import org.springframework.stereotype.Service;");
		sb.append("\n");
		sb.append("import {{packageName}}.domain.{{domainObject}};");
		sb.append("\n");
		sb.append("import {{packageName}}.repository.{{domainObject}}Repository;");
		sb.append("\n");
		sb.append("@Service");
		sb.append("\n");
		sb.append("public class {{domainObject}}Service {");
		sb.append("\n");
		sb.append("\t").append("@Autowired");
		sb.append("\n");
		sb.append("\t").append("private {{domainObject}}Repository<{{domainObject}}> entityRepository;");
		sb.append("\n");
		sb.append("\t").append("@Autowired");
		sb.append("\n");
		sb.append("\t").append("private MongoTemplate mongoTemplate;");
		sb.append("\n").append("\n");
		sb.append("\t").append("public {{domainObject}} create({{domainObject}} entity) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("String textId = UUID.randomUUID().toString();");
		sb.append("\n");
		sb.append("\t").append("\t").append("entity.setId(textId);");
		sb.append("\n");
		sb.append("\t").append("\t").append("// To Do: Write additional setters here.");
		sb.append("\n");
		sb.append("\t").append("\t").append("return entityRepository.save(entity);");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n").append("\n");
		sb.append("\t").append("public {{domainObject}} read({{domainObject}} entity) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("return entity;");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n").append("\n");
		sb.append("\t").append("public Page<{{domainObject}}> readAll(PageRequest page) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("return entityRepository.findAll(page);");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n").append("\n");
		sb.append("\t").append("public List<{{domainObject}}> fetchAllRecords() {");
		sb.append("\n");
		sb.append("\t").append("\t").append("return entityRepository.findAll();");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n").append("\n");
		sb.append("\t").append("public List<{{domainObject}}> filter(Query query) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("return mongoTemplate.find(query, {{domainObject}}.class);");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n").append("\n");
		sb.append("\t").append("public Long getCount(Query query) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("return mongoTemplate.count(query,{{domainObject}}.class);");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n").append("\n");
		sb.append("\t").append("public {{domainObject}} update({{domainObject}} entity) {");
		sb.append("\n");
		sb.append("\t").append("\t")
				.append("{{domainObject}} existingEntity = entityRepository.findById(entity.getId());");
		sb.append("\n");
		sb.append("\t").append("\t").append("if (existingEntity == null) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append("return null;");
		sb.append("\n");
		sb.append("\t").append("\t").append("}");
		sb.append("\n");
		sb.append("\t").append("\t").append("return entityRepository.save({{domainObject}});");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n").append("\n");
		sb.append("\t").append("public Boolean delete({{domainObject}} entity) {");
		sb.append("\n");
		sb.append("\t").append("\t")
				.append("{{domainObject}} existingEntity = entityRepository.findById(entity.getId());");
		sb.append("\n");
		sb.append("\t").append("\t").append("if (existingEntity == null) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append("return false;");
		sb.append("\n");
		sb.append("\t").append("\t").append("}");
		sb.append("\n");
		sb.append("\t").append("\t").append("entityRepository.delete(existingEntity);");
		sb.append("\n");
		sb.append("\t").append("\t").append("return true;");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n");
		sb.append("}");
		
		return sb.toString();
	}

}
