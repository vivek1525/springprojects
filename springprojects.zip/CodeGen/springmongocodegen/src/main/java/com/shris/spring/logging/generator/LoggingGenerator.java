package com.shris.spring.logging.generator;

// Logging is handled through other Generators. Need not implement any thing here.
public class LoggingGenerator {}
