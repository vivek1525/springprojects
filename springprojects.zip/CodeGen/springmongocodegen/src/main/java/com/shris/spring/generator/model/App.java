package com.shris.spring.generator.model;

import java.util.List;

import com.shris.spring.generator.model.Entity;

public class App {

	private String angularModule;
	private String client;
	private String serverProjectPath;
	private List<Entity> entities;

	public String getAngularModule() {
		if (angularModule == null || angularModule.isEmpty()) {
			return client;
		}
		return angularModule;
	}

	public String getClient() {
		return client;
	}

	public String getServerProjectPath() {
		return serverProjectPath;
	}

	public void setServerProjectPath(String serverProjectPath) {
		this.serverProjectPath = serverProjectPath;
	}

	public void setClient(String client) {
		this.client = client;
	}

	public void setAngularModule(String angularModule) {
		this.angularModule = angularModule;
	}

	public List<Entity> getEntities() {
		return entities;
	}

	public void setEntities(List<Entity> entities) {
		this.entities = entities;
	}
}
