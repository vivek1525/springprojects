package com.shris.spring.generator;

import java.io.File;

import org.apache.commons.io.FileUtils;

import com.samskivert.mustache.Mustache;
import com.samskivert.mustache.Template;

public abstract class AbstractGenerator implements Generator {

	private Template mustacheTemplate;
	private Parameters params;
	
	public void generate(Parameters params) throws Exception {
		this.params = params;
		mustacheTemplate = Mustache.compiler().compile(getTemplate().getReader());
		String fileContent = mustacheTemplate.execute(params);
		fileContent = format(fileContent);
		final String fileName = getFileName(params);
		
		File fileToCreate = new File(String.valueOf(fileName));
		if( !fileToCreate.exists() || (fileToCreate.exists() && params.isOverrideExisting()))
		{
			FileUtils.writeStringToFile(new File(fileName), fileContent);
		}
		
		
		//FileUtils.writeStringToFile(new File(fileName), fileContent);
	}
	
	
	protected String format(String fileContent) {
		return fileContent;
	}


	public Parameters getParams() {
		return params;
	}

	/** Name of the file to which content needs to be written */
	protected abstract String getFileName(Parameters params);

	/** Template class from which content needs to be fetched. */
	protected abstract com.shris.spring.generator.Template getTemplate();
}