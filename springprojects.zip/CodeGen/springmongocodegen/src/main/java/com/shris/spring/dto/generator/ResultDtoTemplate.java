package com.shris.spring.dto.generator;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.shris.spring.generator.Template;

public class ResultDtoTemplate implements Template{

	public Reader getReader() {
		final InputStream is = getClass().getClassLoader().getResourceAsStream("ResultListDto.mustache");
		final BufferedReader br = new BufferedReader(new InputStreamReader(is));
		return br;
	}
	
	public String getTemplate() {

		StringBuilder sb = new StringBuilder();
		sb.append("package {{packageName}}.dto;");
		sb.append("\n");
		sb.append("import java.util.List;");
		sb.append("\n");
		sb.append("public class ResultListDto<T> {");
		sb.append("\n");
		sb.append("\t").append("private List<T> resultList;");
		sb.append("\n");
		sb.append("\t").append("private int pageCount;");
		sb.append("\n");
		sb.append("\t").append("private int currentPage;");
		sb.append("\n");
		sb.append("\t").append("private long totalCount;");
		sb.append("\n");
		sb.append("\t").append("public List<T> getResultList() {");
		sb.append("\n");
		sb.append("\t").append("\t").append("return resultList;");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n");
		sb.append("\t").append("public void setResultList(List<T> resultList) { ");
		sb.append("\n");
		sb.append("\t").append("\t").append("this.resultList = resultList;");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n");
		sb.append("\t").append("public int getPageCount() { ");
		sb.append("\n");
		sb.append("\t").append("\t").append("return pageCount;");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n");
		sb.append("\t").append("public void setPageCount(int pageCount) { ");
		sb.append("\n");
		sb.append("\t").append("\t").append("this.pageCount = pageCount;");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n");
		sb.append("\t").append("public int getCurrentPage() { ");
		sb.append("\n");
		sb.append("\t").append("\t").append("return currentPage;");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n");
		sb.append("\t").append("public void setCurrentPage(int currentPage) { ");
		sb.append("\n");
		sb.append("\t").append("\t").append("this.currentPage = currentPage;");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n");
		sb.append("\t").append("public long getTotalCount() { ");
		sb.append("\n");
		sb.append("\t").append("\t").append("return totalCount;");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n");
		sb.append("\t").append("public void setTotalCount(long totalCount) { ");
		sb.append("\n");
		sb.append("\t").append("\t").append("this.totalCount = totalCount;");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n");
		sb.append("}");
		return sb.toString();
	}
	
}
