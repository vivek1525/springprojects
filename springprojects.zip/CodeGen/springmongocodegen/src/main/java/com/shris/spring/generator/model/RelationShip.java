package com.shris.spring.generator.model;

public enum RelationShip {
	OneToOne, OneToMany, ManyToOne, ManyToMany
}
