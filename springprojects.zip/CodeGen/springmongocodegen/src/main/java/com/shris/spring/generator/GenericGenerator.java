package com.shris.spring.generator;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class GenericGenerator extends AbstractGenerator {

	String sourceFileName;
	String destinationFilePath;
	Parameters params;
	
	public Parameters getParams() {
		return params;
	}

	public GenericGenerator setParams(Parameters params) {
		this.params = params;
		return this;
	}

	public GenericGenerator() {
		
	}

	public GenericGenerator setSourceFileName(String sourceFileName) {
		this.sourceFileName = sourceFileName;
		return this;
	}

	public GenericGenerator setDestinationFilePath(String destinationFilePath) {
		this.destinationFilePath = destinationFilePath;
		return this;
	}
	
	public GenericGenerator generate() throws Exception {
		super.generate(this.params);
		return this;
	}
	

	public String getSourceFileName() {
		return sourceFileName;
	}

	public String getDestinationFilePath() {
		return destinationFilePath;
	}

	@Override
	protected String getFileName(Parameters params) {
		return destinationFilePath;
	}

	@Override
	protected Template getTemplate() {
		return new Template() {

			public Reader getReader() {
				final InputStream is = getClass().getClassLoader().getResourceAsStream(sourceFileName);
				final BufferedReader br = new BufferedReader(new InputStreamReader(is));
				return br;
			}
		};
	}
}
