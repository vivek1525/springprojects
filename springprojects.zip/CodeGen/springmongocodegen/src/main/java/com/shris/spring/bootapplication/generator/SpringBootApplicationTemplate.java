package com.shris.spring.bootapplication.generator;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.shris.spring.generator.Template;

public class SpringBootApplicationTemplate implements Template{
	
	public Reader getReader() {
		final InputStream is = getClass().getClassLoader().getResourceAsStream("Application.mustache");
		final BufferedReader br = new BufferedReader(new InputStreamReader(is));
		return br;
	}

	public String getTemplate() {
		return null;
	}
	
}