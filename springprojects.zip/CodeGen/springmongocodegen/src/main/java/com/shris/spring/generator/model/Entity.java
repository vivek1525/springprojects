package com.shris.spring.generator.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Entity {
	
	private String name;
	private int rowsPerPage;
	private int columnsPerPage = 1;
	private boolean enableMultiSelectInList;
	private AddNewMethod addNewMethodInListPage;
	private int numberOfFormColumns = 1;
	private Orientation tabOrderOrientation = Orientation.Vertical;
	private boolean auditable;
	private boolean softDelete;
	private boolean addNewMethodInline;
	private String authName;
	private String entryStateName;
	private String entryStateHeader;
	private String moduleForRestApi;
	private boolean enterpriseSpecific;
	private boolean overrideExisting;
	
	List<Field> fields;
	
public enum AddNewMethod {
		Popup, Newtab
	};

	public enum Orientation {
		Horizantal, Vertical
	};
	
		public Entity() {

	}

	public Entity(final String name) {
		this.name = name;
	}
	
	public int getNumberOfFormColumns() {
		return numberOfFormColumns;
	}

	public void setNumberOfFormColumns(int numberOfFormColumns) {
		this.numberOfFormColumns = numberOfFormColumns;
	}

	public Orientation getTabOrderOrientation() {
		return tabOrderOrientation;
	}

	public void setTabOrderOrientation(Orientation tabOrderOrientation) {
		this.tabOrderOrientation = tabOrderOrientation;
	}
	public boolean getAuditable() {
		return auditable;
	}
	public void setAuditable(boolean auditable) {
		this.auditable = auditable;
	}
	
	public boolean getSoftDelete() {
		return softDelete;
	}
	
	public void setSoftDelete(boolean softDelete) {
		this.softDelete = softDelete;
	}
	
	public boolean getEnterpriseSpecific() {
		return enterpriseSpecific;
	}
	public void setEnterpriseSpecific(boolean enterpriseSpecific) {
		this.enterpriseSpecific = enterpriseSpecific;
	}
	
	public boolean isOverrideExisting() {
		return overrideExisting;
	}

	public void setOverrideExisting(boolean overrideExisting) {
		this.overrideExisting = overrideExisting;
	}

	public boolean isAddNewMethodInline() {
		return addNewMethodInline;
	}

	public void setAddNewMethodInline(boolean addNewMethodInline) {
		this.addNewMethodInline = addNewMethodInline;
	}

	public int getRowsPerPage() {
		return rowsPerPage;
	}
	
	public int getColumnsPerPage() {
		return columnsPerPage;
	}

	public void setColumnsPerPage(int columnsPerPage) {
		this.columnsPerPage = columnsPerPage;
	}

	public void setRowsPerPage(int rowsPerPage) {
		this.rowsPerPage = rowsPerPage;
	}

	public boolean isEnableMultiSelectInList() {
		return enableMultiSelectInList;
	}

	public void setEnableMultiSelectInList(boolean enableMultiSelectInList) {
		this.enableMultiSelectInList = enableMultiSelectInList;
	}

	public AddNewMethod getAddNewMethodInListPage() {
		return addNewMethodInListPage;
	}

	public void setAddNewMethodInListPage(AddNewMethod addNewMethodInListPage) {
		this.addNewMethodInListPage = addNewMethodInListPage;
	}


	public void setName(String name) {
		this.name = name;
	}

	public String getNgModelName() {
		return this.getName().substring(0, 1).toLowerCase() + this.getName().substring(1).trim() + "Model";
	}

	public String getAuthName() {
		return authName;
	}

	public void setAuthName(String authName) {
		this.authName = authName;
	}

	public String getEntryStateName() {
		return entryStateName;
	}

	public void setEntryStateName(String entryStateName) {
		this.entryStateName = entryStateName;
	}

	public String getEntryStateHeader() {
		return entryStateHeader;
	}

	public void setEntryStateHeader(String entryStateHeader) {
		this.entryStateHeader = entryStateHeader;
	}

	public String getModuleForRestApi() {
		return moduleForRestApi;
	}

	public void setModuleForRestApi(String moduleForRestApi) {
		this.moduleForRestApi = moduleForRestApi;
	}
	
	public String getName() {
		return this.name.replace(" ", "");
	}
	
	public String getDisplayName() {
		return this.name;
	}
	
	public String getNameLower() {
		return this.getName().toLowerCase();
	}

	public String getNameUpper() {
		return this.getName().toUpperCase();
	}
	
	public String getNameCamel() {
		return this.getName().substring(0, 1).toLowerCase() + this.getName().substring(1).trim();
	}

	public List<Field> getFields() {
		// Sort fields by tab order
		Collections.sort(fields);
		return fields;
	}

	public void setFields(List<Field> fields) {
		this.fields = fields;
	}
	
	public String getUnique() {
		// @Unique(unique= {@UniqueFields(fields = {"name"}), @UniqueFields(fields= {"name"})})
		StringBuilder unique = new StringBuilder("");
		List<String> uniqueFiledsList = new ArrayList<String>();
		
		for (Field field : fields) {
			if(field.getRestrictions() != null && field.getRestrictions().isUnique()) {
				uniqueFiledsList.add("@UniqueFields(fields = {#q#" + field.getName() + "#q#})");
			}
		}
		
		if(!uniqueFiledsList.isEmpty()) {
			unique.append("@Unique(unique= {");
			for (int i = 0; i < uniqueFiledsList.size(); i++) {
				if(i == 0) {
					unique.append(uniqueFiledsList.get(i));
				} else {
					unique.append(", " + uniqueFiledsList.get(i));
				}
			}
			unique.append("})");
		}
		
		return unique.toString();
	}
	
	public Field getDisplayFiled() {
		
		for (Field field : fields) {
			if(field.getIsDisplayField()) {
				return field;
			}
		}
		
		return null;
	}
}
