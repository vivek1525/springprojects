package com.shris.spring.service.generator;

import java.io.File;

import com.shris.spring.generator.AbstractGenerator;
import com.shris.spring.generator.Parameters;
import com.shris.spring.generator.Template;

public class S3ServiceGenerator extends AbstractGenerator {
	
	final S3ServiceTemplate s3Service = new S3ServiceTemplate();

	/** Name of the file to which content needs to be written */
	protected String getFileName(Parameters params) {

		final StringBuilder fileNameBuilder = new StringBuilder();
		fileNameBuilder.append(params.getSrcRoot()).append(File.separator).append("com").append(File.separator)
				.append(params.getOrganization()).append(File.separator).append("generic").append(File.separator)
				.append("service").append(File.separator)
				.append("S3Service.java");

		return fileNameBuilder.toString();
	}

	/** Template class from which content needs to be fetched. */
	protected Template getTemplate() {
		return s3Service;
	}
}