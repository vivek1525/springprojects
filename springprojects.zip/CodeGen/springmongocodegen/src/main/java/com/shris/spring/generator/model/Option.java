package com.shris.spring.generator.model;

/**
 * 
 * Indicates any option
 *
 */
public class Option {
	
	private String name;
	private String label;
	private Restrictions restrictions;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public Restrictions getRestrictions() {
		return restrictions;
	}
	public void setRestrictions(Restrictions restrictions) {
		this.restrictions = restrictions;
	}
}
