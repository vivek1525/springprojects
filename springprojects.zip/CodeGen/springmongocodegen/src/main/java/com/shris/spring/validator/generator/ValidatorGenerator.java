package com.shris.spring.validator.generator;

import java.io.File;

import com.shris.spring.generator.AbstractGenerator;
import com.shris.spring.generator.Parameters;
import com.shris.spring.generator.Template;


public class ValidatorGenerator extends AbstractGenerator {
	
	final ValidatorTemplate validatorTemplate = new ValidatorTemplate();
    
		
	/** Name of the file to which content needs to be written */
	protected String getFileName(Parameters params) {
		
		final StringBuilder fileNameBuilder = new StringBuilder();
		fileNameBuilder.append(params.getSrcRoot())
					   .append(File.separator)
					   .append("com")
					   .append(File.separator)
					   .append(params.getOrganization())
					   .append(File.separator)
					   .append("validator")
					   .append(File.separator)
					   .append(params.getEntity())
					   .append("Validator.java");

		return fileNameBuilder.toString();
	}

	/** Template class from which content needs to be fetched. */
	protected Template getTemplate() {
		return validatorTemplate;
	}
}
