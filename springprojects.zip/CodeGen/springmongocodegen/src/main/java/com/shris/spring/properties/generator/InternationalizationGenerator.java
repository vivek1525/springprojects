package com.shris.spring.properties.generator;

import java.io.File;

import com.shris.spring.generator.AbstractGenerator;
import com.shris.spring.generator.Parameters;
import com.shris.spring.generator.Template;

public class InternationalizationGenerator extends AbstractGenerator{
	
	final InternationalizationTemplate template = new InternationalizationTemplate();
	private String locale;
	
	public InternationalizationGenerator(final String locale) {
		this.locale = locale;
	}
	/** Name of the file to which content needs to be written */
	protected String getFileName(Parameters params) {
		
		final StringBuilder fileNameBuilder = new StringBuilder();
		fileNameBuilder.append(params.getResourcesRoot())
					   .append(File.separator)
					   .append("i18n")
					   .append(File.separator)
					   .append("messages" + locale  + ".properties");

		return fileNameBuilder.toString();
	}

	/** Template class from which content needs to be fetched. */
	protected Template getTemplate() {
		return template;
	}
}