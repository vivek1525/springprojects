package com.shris.spring.properties.generator;

import java.io.File;

import com.shris.spring.generator.AbstractGenerator;
import com.shris.spring.generator.Parameters;
import com.shris.spring.generator.Template;

public class BannerGenerator extends AbstractGenerator{
	
	final PropertiesTemplate propertiesTemplate = new PropertiesTemplate();

	/** Name of the file to which content needs to be written */
	protected String getFileName(Parameters params) {
		
		final StringBuilder fileNameBuilder = new StringBuilder();
		fileNameBuilder.append(params.getResourcesRoot())
					   .append(File.separator)
					   .append("banner.txt");

		return fileNameBuilder.toString();
	}

	/** Template class from which content needs to be fetched. */
	protected Template getTemplate() {
		return propertiesTemplate;
	}
}
