package com.shris.spring.controller.generator;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.shris.spring.generator.Template;

public class SpringControllerTemplate implements Template {
	
	public Reader getReader() {
		final InputStream is = getClass().getClassLoader().getResourceAsStream("ControllerTemplate.mustache");
		final BufferedReader br = new BufferedReader(new InputStreamReader(is));
		return br;
	}
	
	public String getTemplate() {

		StringBuilder sb = new StringBuilder();
		sb.append("package {{packageName}}.controller;");
		sb.append("\n");
		sb.append("import java.io.IOException;");
		sb.append("\n");
		sb.append("import java.util.List;");
		sb.append("\n");
		sb.append("import org.codehaus.jackson.JsonParseException;");
		sb.append("\n");
		sb.append("import org.codehaus.jackson.map.JsonMappingException;");
		sb.append("\n");
		sb.append("import org.json.simple.JSONObject;");
		sb.append("\n");
		sb.append("import org.springframework.beans.factory.annotation.Autowired;");
		sb.append("\n");
		sb.append("import org.springframework.data.domain.Page;");
		sb.append("\n");
		sb.append("import org.springframework.data.domain.PageRequest;");
		sb.append("\n");
		sb.append("import org.springframework.data.domain.Sort;");
		sb.append("\n");
		sb.append("import org.springframework.data.mongodb.core.query.Query;");
		sb.append("\n");
		sb.append("import org.springframework.security.access.prepost.PreAuthorize;");
		sb.append("\n");
		sb.append("import org.springframework.stereotype.Controller;");
		sb.append("\n");
		sb.append("import org.springframework.web.bind.annotation.PathVariable;");
		sb.append("\n");
		sb.append("import org.springframework.web.bind.annotation.RequestBody;");
		sb.append("\n");
		sb.append("import org.springframework.web.bind.annotation.RequestMapping;");
		sb.append("\n");
		sb.append("import org.springframework.web.bind.annotation.RequestMethod;");
		sb.append("\n");
		sb.append("import org.springframework.web.bind.annotation.RequestParam;");
		sb.append("\n");
		sb.append("import org.springframework.web.bind.annotation.ResponseBody;");
		sb.append("\n");
		sb.append("import {{packageName}}.domain.{{domainObject}};");
		sb.append("\n");
		sb.append("import {{packageName}}.dto.ResultListDto;");
		sb.append("\n");
		sb.append("import {{packageName}}.service.{{domainObject}}BusinessService;");
		sb.append("\n").append("\n");
		sb.append("@Controller");
		sb.append("\n");
		sb.append("@RequestMapping(\"/{{domainObjectCamelCase}}\")");
		sb.append("\n");
		sb.append("public class {{domainObject}}Controller {");
		sb.append("\n");
		sb.append("\t").append("@Autowired");
		sb.append("\n");
		sb.append("\t").append("private {{domainObject}}BusinessService service;");
		sb.append("\n").append("\n");
		sb.append("\t")
				.append("// To Do : Set role configuration : Ex: @PreAuthorize(\"hasAuthority('BROKERACCOUNT_VIEW')\")");
		sb.append("\n");
		sb.append("\t").append("@RequestMapping(value = \"/records/{page}\")");
		sb.append("\n");
		sb.append("\t").append(
				"public @ResponseBody ResultListDto<{{domainObject}}> getAllRecords(@PathVariable(\"page\") int page) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("// To Do: Set right page limit");
		sb.append("\n");
		sb.append("\t").append("\t")
				.append("final PageRequest pageRequest = new PageRequest(page, 10,Sort.Direction.DESC,\"updatedOn\");");
		sb.append("\n");
		sb.append("\t").append("\t").append("Page<{{domainObject}}> pageList = service.readAll(pageRequest);");
		sb.append("\n");
		sb.append("\t").append("\t").append(
				"ResultListDto<{{domainObject}}> brokerAccountListDto = new ResultListDto<{{domainObject}}>();");
		sb.append("\n");
		sb.append("\t").append("\t").append("brokerAccountListDto.setResultList(pageList.getContent());");
		sb.append("\n");
		sb.append("\t").append("\t").append("brokerAccountListDto.setPageCount(pageList.getTotalPages());");
		sb.append("\n");
		sb.append("\t").append("\t").append("brokerAccountListDto.setTotalCount(pageList.getTotalElements());");
		sb.append("\n");
		sb.append("\t").append("\t").append("brokerAccountListDto.setCurrentPage(page);");
		sb.append("\n");
		sb.append("\t").append("\t").append("return brokerAccountListDto;");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n").append("\n");
		sb.append("\t")
				.append("// To Do : Set role configuration : Ex: @PreAuthorize(\"hasAuthority('BROKERACCOUNT_VIEW')\")");
		sb.append("\n");
		sb.append("\t").append("@RequestMapping(value = \"/fetchAllRecords\")");
		sb.append("\n");
		sb.append("\t").append("public @ResponseBody ResultListDto<{{domainObject}}> fetchAllRecords() {");
		sb.append("\n");
		sb.append("\t").append("\t").append("List<BrokerAccount> pageList = service.fetchAllRecords();");
		sb.append("\n");
		sb.append("\t").append("\t")
				.append("ResultListDto<{{domainObject}}> resultListDto = new ResultListDto<{{domainObject}}>();");
		sb.append("\n");
		sb.append("\t").append("\t").append("resultListDto.setResultList(pageList);");
		sb.append("\n");
		sb.append("\t").append("\t").append("return resultListDto;");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n");
		sb.append("\n").append("\n");
		sb.append("\n");
		sb.append("\t")
				.append("// To Do : Set role configuration : Ex: @PreAuthorize(\"hasAuthority('BROKERACCOUNT_VIEW')\")");
		sb.append("\n");
		sb.append("\t").append("@RequestMapping(value = \"/filterByKeys\", method = RequestMethod.POST)");
		sb.append("\n");
		sb.append("\t").append(
				"public @ResponseBody ResultListDto<{{domainObject}}> filterByKeys(@RequestBody JSONObject filterJson) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t")
				.append("Query queryFromJson = queryUtil.createQueryFromJson(filterJson);");
		sb.append("\n");
		sb.append("\t").append("\t")
				.append("ResultListDto<{{domainObject}}> resultListDto = new ResultListDto<{{domainObject}}>();");
		sb.append("\n");
		sb.append("\t").append("\t").append("resultListDto.setResultList(service.filter(queryFromJson));");
		sb.append("\n");
		sb.append("\t").append("\t").append("resultListDto.setTotalCount(service.getCount(queryFromJson));");
		sb.append("\n");
		sb.append("\t").append("\t").append("if(filterJson.get(\"page\")!=null) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t")
				.append("resultListDto.setCurrentPage(Integer.parseInt(filterJson.get(\"page\").toString())\");");
		sb.append("\n");
		sb.append("\t").append("\t").append("}");
		sb.append("\n");
		sb.append("\t").append("\t").append("return resultListDto;");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n");
		sb.append("\t")
				.append("// To Do : Set role configuration : Ex: @PreAuthorize(\"hasAuthority('BROKERACCOUNT_VIEW')\")");
		sb.append("\n");
		sb.append("\t").append("@RequestMapping(value = \"/create\", method = RequestMethod.POST)");
		sb.append("\n");
		sb.append("\t").append("public @ResponseBody {{domainObject}} create(@RequestBody String jsonInputString) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("{{domainObject}} {{domainObjectCamelCase}} = null;");
		sb.append("\n");
		sb.append("\t").append("\t").append("try {");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append("{{domainObjectCamelCase}} = new {{domainObject}}();");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append(
				"{{domainObjectCamelCase}} = {{domainObjectCamelCase}}.getBrokerAccountFromJson(jsonInputString);");
		sb.append("\n");
		sb.append("\t").append("\t").append("} catch (JsonMappingException e1) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append("// TODO Auto-generated catch block");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append("e1.printStackTrace();");
		sb.append("\n");
		sb.append("\t").append("\t").append("} catch (JsonParseException e1) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append("// TODO Auto-generated catch block");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append("e1.printStackTrace();");
		sb.append("\n");
		sb.append("\t").append("\t").append("} catch (} catch (IOException e1) {) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append("// TODO Auto-generated catch block");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append("e1.printStackTrace();");
		sb.append("\n");
		sb.append("\t").append("\t").append("}");
		sb.append("\n");
		sb.append("\t").append("\t").append("return service.create({{domainObjectCamelCase}});");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n").append("\n");
		sb.append("\t")
				.append("// To Do : Set role configuration : Ex: @PreAuthorize(\"hasAuthority('BROKERACCOUNT_UPDATE')\"));");
		sb.append("\n");
		sb.append("\t").append("@RequestMapping(value = \"/update\", method = RequestMethod.PUT)");
		sb.append("\n");
		sb.append("\t").append("public @ResponseBody {{domainObject}} update(@RequestBody String jsonInputString) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("{{domainObject}} brokerAccount = null;");
		sb.append("\n");
		sb.append("\t").append("\t").append("try {");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append("{{domainObjectCamelCase}} = new {{domainObject}}();");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append(
				"{{domainObjectCamelCase}} = {{domainObjectCamelCase}}.getBrokerAccountFromJson(jsonInputString);");
		sb.append("\n");
		sb.append("\t").append("\t").append("} catch (JsonMappingException e1) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append("// TODO Auto-generated catch block");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append("e1.printStackTrace();");
		sb.append("\n");
		sb.append("\t").append("\t").append("} catch (JsonParseException e1) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append("// TODO Auto-generated catch block");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append("e1.printStackTrace();");
		sb.append("\n");
		sb.append("\t").append("\t").append("} catch (} catch (IOException e1) {) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append("// TODO Auto-generated catch block");
		sb.append("\n");
		sb.append("\t").append("\t").append("\t").append("e1.printStackTrace();");
		sb.append("\n");
		sb.append("\t").append("\t").append("}");
		sb.append("\n");
		sb.append("\t").append("\t").append("return service.update({{domainObjectCamelCase}});");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n").append("\n");
		sb.append("\t")
				.append("// To Do : Set role configuration : Ex: @PreAuthorize(\"hasAuthority('BROKERACCOUNT_DELETE')\"));");
		sb.append("\n");
		sb.append("\t").append("@RequestMapping(value = \"/delete\", method = RequestMethod.DELETE)");
		sb.append("\n");
		sb.append("\t").append("public @ResponseBody Boolean delete(@RequestParam String id) {");
		sb.append("\n");
		sb.append("\t").append("\t").append("{{domainObject}} {{domainObjectCamelCase}} = new {{domainObject}}();");
		sb.append("\n");
		sb.append("\t").append("\t").append("{{domainObjectCamelCase}}.setId(id);");
		sb.append("\n");
		sb.append("\t").append("\t").append("return service.delete({{domainObjectCamelCase}});");
		sb.append("\n");
		sb.append("\t").append("}");
		sb.append("\n");
		sb.append("}");
		return sb.toString();

	}

	

}
