package com.shris.spring.service.generator;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.shris.spring.generator.Parameters;
import com.shris.spring.generator.Template;

public class SpringDataServiceTemplate implements Template {

	private Parameters params;

	public SpringDataServiceTemplate() {
	}

	public SpringDataServiceTemplate(Parameters params) {
		this.params = params;
	}

	public Reader getReader() {
		String templateName = "DataService.mustache";
		if (params != null && params.getCurrentEntity() != null && params.getCurrentEntity().getSoftDelete()) {
			templateName = "SoftDeleteDataServiceTemplate.mustache";
		}
		final InputStream is = getClass().getClassLoader().getResourceAsStream(templateName);
		final BufferedReader br = new BufferedReader(new InputStreamReader(is));
		return br;
	}
}
