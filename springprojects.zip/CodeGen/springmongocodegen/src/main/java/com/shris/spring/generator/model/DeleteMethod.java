package com.shris.spring.generator.model;

public enum DeleteMethod {
	Hard, Soft
}
