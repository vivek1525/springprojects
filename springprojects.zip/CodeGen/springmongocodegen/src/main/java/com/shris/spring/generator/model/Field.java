package com.shris.spring.generator.model;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

public class Field implements Comparable<Field>{
	
	private String name;
	private String label;
	private String defaultValue;
	private Type type;
	private String javaType;
	private Restrictions restrictions;
	private RelationShip realtionShip = RelationShip.OneToOne;
	private int tabOrder;
	private List<Option> options;
	private boolean isEntityReference = false;
	private boolean isDisplayField = false;
	private boolean isIdField = false;
	// ---------------------------------
	private boolean required;
	private String mask;
	private boolean defaultInListView;
	private String columnFilter;
	private boolean inlineEditing;
	private boolean addNewData;
	private boolean defaultSort;
	private int columnSpan = 1;
	private boolean auditable;
	private Entity entity;
	private boolean displayInListScreen;
	private boolean permanentInListScreen;
	private String collectionName;
	private String restCallToFetch;
	private String subField;
	private String statValuesName;
	private String statValuesList;
	
	private String getOrPostCall;
	private String lookupTypeName;
	private String lookupFieldName;
	private String domainLookup;
	private int column = 1;
	private boolean firstColumn = true;
	
	private int index = 1;
	private int size;

	public Field() {
	}

	public Field(Entity entity) {this.entity = entity;}
	
	private String symbolToBeAppendedForValue;
	private boolean appendSymbolToRight;
	private String maskType;
	
	
	public String getMaskType() {
		return maskType;
	}
	
	public void setMaskType(String maskType) {
		this.maskType = maskType;
	}
	
	public String getSymbolToBeAppendedForValue() {
		return symbolToBeAppendedForValue;
	}
	
	public void setSymbolToBeAppendedForValue(String symbolToBeAppendedForValue) {
		this.symbolToBeAppendedForValue = symbolToBeAppendedForValue;
	}
	
	public boolean isAppendSymbolToRight() {
		return appendSymbolToRight;
	}
	public void setAppendSymbolToRight(boolean appendSymbolToRight) {
		this.appendSymbolToRight = appendSymbolToRight;
	}
	public int getColumn() {
		return column;
	}
	public void setColumn(int column) {
		this.column = column;
	}

	public String getStatValuesName() {
		return statValuesName;
	}

	public void setStatValuesName(String statValuesName) {
		this.statValuesName = statValuesName;
	}

	public String getStatValuesList() {
		return statValuesList;
	}

	public void setStatValuesList(String statValuesList) {
		this.statValuesList = statValuesList;
	}

	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

	public String getMask() {
		return mask;
	}

	public void setMask(String mask) {
		this.mask = mask;
	}

	public boolean isDefaultInListView() {
		return defaultInListView;
	}

	public void setDefaultInListView(boolean defaultInListView) {
		this.defaultInListView = defaultInListView;
	}

	public String getColumnFilter() {
		return columnFilter;
	}

	public void setColumnFilter(String columnFilter) {
		this.columnFilter = columnFilter;
	}

	public boolean isInlineEditing() {
		return inlineEditing;
	}

	public void setInlineEditing(boolean inlineEditing) {
		this.inlineEditing = inlineEditing;
	}

	public int getTabOrder() {
		return tabOrder;
	}

	public void setTabOrder(int tabOrder) {
		this.tabOrder = tabOrder;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public boolean isRequired() {
		return required;
	}

	public void setRequired(boolean required) {
		this.required = required;
	}
	public Type getType() {
		return type;
	}
	public void setType(Type type) {
		this.type = type;
	}
	
	public boolean isAddNewData() {
		return addNewData;
	}

	public void setAddNewData(boolean addNewData) {
		this.addNewData = addNewData;
	}

	public boolean isDefaultSort() {
		return defaultSort;
	}

	public void setDefaultSort(boolean defaultSort) {
		this.defaultSort = defaultSort;
	}

	public int getColumnSpan() {
		return columnSpan;
	}

	public void setColumnSpan(int columnSpan) {
		this.columnSpan = columnSpan;
	}

	public boolean isAuditable() {
		return auditable;
	}

	public void setAuditable(boolean auditable) {
		this.auditable = auditable;
	}

	public Entity getEntity() {
		return entity;
	}

	public void setEntity(Entity entity) {
		this.entity = entity;
	}
	@Override
	public String toString() {
		return "(Name=" + name + ", Label=" + label + ", Required=" + required + ", Type=" + type + ")";
	}
	public int compareTo(Field f) {
		return this.getTabOrder() - f.getTabOrder();
	}
	public String getNgModelName() {
		return this.getEntity().getNgModelName() + "." + this.getName();
	}
	
	public boolean getDefaultSpecified() {
		return StringUtils.isEmpty(defaultValue);
	}

	public boolean getIsSelect() {
		return Type.select.equals(type);
	}

	public boolean isDisplayInListScreen() {
		return displayInListScreen;
	}

	public void setDisplayInListScreen(boolean displayInListScreen) {
		this.displayInListScreen = displayInListScreen;
	}

	public boolean isPermanentInListScreen() {
		return permanentInListScreen;
	}

	public void setPermanentInListScreen(boolean permanentInListScreen) {
		this.permanentInListScreen = permanentInListScreen;
	}

	public boolean getForeignKey() {
		return !StringUtils.isEmpty(this.getRestCallToFetch());
	}

	public String getCollectionName() {
		return collectionName;
	}

	public void setCollectionName(String collectionName) {
		this.collectionName = collectionName;
	}

	
	public boolean getIsStaticSelectField() {
		return Type.staticselect.equals(type);
	}
	public boolean getIsSelectField() {
		return Type.select.equals(type);
	}
	public boolean getIsLookupSelectField() {
		return Type.lookupselect.equals(type);
	}
	
	public boolean getIsDateField() {
		return Type.date.equals(type);
	}
	
	public boolean getIsFileField() {
		return Type.file.equals(type);
	}
	
	public boolean getIsTextField() {
		return !Type.date.equals(type) &&!Type.time.equals(type) && !Type.staticselect.equals(type) &&
				!Type.select.equals(type) && !Type.lookupselect.equals(type) && !Type.checkbox.equals(type) && !Type.file.equals(type);
	}
	
	public boolean getIsCheckbox() {
		return Type.checkbox.equals(type);
	}
	
	public String getName() {
		return this.name.replace(" ", "");
	}
	
	public String getDisplayName() {
		return this.name;
	}

	public String getNameLower() {
		return this.getName().toLowerCase();
	}

	public String getNameUpper() {
		return this.getName().toUpperCase();
	}

	public String getNameCamel() {
		return this.getName().substring(0, 1).toLowerCase() + this.getName().substring(1).trim();
	}

	public String getRestCallToFetch() {
		return restCallToFetch;
	}

	public void setRestCallToFetch(String restCallToFetch) {
		this.restCallToFetch = restCallToFetch;
	}

	public String getSubField() {
		return subField;
	}

	public void setSubField(String subField) {
		this.subField = subField;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}
	
	public boolean getIsEven() {
		return ((getIndex()%3) != 1);
	}
	
	public boolean getIsFirstColumn() 
	{
		if(entity != null && entity.getColumnsPerPage() == 2 && this.column != 1)
		{
			firstColumn = false;
		}
		return firstColumn;
	}
	
	public boolean getIsOdd() {
		return ((getIndex()%3) == 1);
	}
	
	public boolean getIsFirst() {
		return getIndex() == 1;
	}

	public boolean getIsLast() {
		return getIndex() == getSize();
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public Restrictions getRestrictions() {
		return restrictions;
	}

	public void setRestrictions(Restrictions restrictions) {
		this.restrictions = restrictions;
	}

public String getGetOrPostCall() {
		return getOrPostCall;
	}
	public void setGetOrPostCall(String getOrPostCall) {
		this.getOrPostCall = getOrPostCall;
	}
	public String getLookupTypeName() {
		return lookupTypeName;
	}
	public void setLookupTypeName(String lookupTypeName) {
		this.lookupTypeName = lookupTypeName;
	}
	public String getLookupFieldName() {
		return lookupFieldName;
	}
	public void setLookupFieldName(String lookupFieldName) {
		this.lookupFieldName = lookupFieldName;
	}
	public String getDomainLookup() {
		return domainLookup;
	}
	public void setDomainLookup(String domainLookup) {
		this.domainLookup = domainLookup;
	}
	public boolean getIsMaskTypePercentage() {
		System.out.println(this.maskType);
		return (this.maskType != null && this.maskType.equals("percent"));
	}
	
	public List<Option> getOptions() {
		return options;
	}

	public void setOptions(List<Option> options) {
		this.options = options;
	}

	
	public String getJavaType() {
		return javaType;
	}
	public void setJavaType(String javaType) {
		this.javaType = javaType;
	}
	public String getNameCamelCase() {
		return name.substring(0, 1).toUpperCase() + name.substring(1);
	}
	public RelationShip getRealtionShip() {
		return realtionShip;
	}
	public void setRealtionShip(RelationShip realtionShip) {
		this.realtionShip = realtionShip;
	}
	public boolean getIsOneToMany() {
		return RelationShip.OneToMany.equals(realtionShip);
	}
	
	public boolean getIsManyToMany() {
		return RelationShip.ManyToMany.equals(realtionShip);
	}
	
	public boolean getIsManyToOne() {
		return RelationShip.ManyToOne.equals(realtionShip);
	}
	
	public boolean getIsOneToOne() {
		return RelationShip.OneToOne.equals(realtionShip);
	}

	public boolean getIsEntityReference() {
		return isEntityReference;
	}

	public void setEntityReference(boolean isEntityReference) {
		this.isEntityReference = isEntityReference;
	}

	public boolean getIsDisplayField() {
		return isDisplayField;
	}

	public void setDisplayField(boolean isDisplayField) {
		this.isDisplayField = isDisplayField;
	}

	public boolean getIsIdField() {
		return isIdField;
	}

	public void setIdField(boolean isIdField) {
		this.isIdField = isIdField;
	}
	
	
	
}
