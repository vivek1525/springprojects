package com.shris.spring.generator;

import java.io.Reader;

public interface Template {
	public Reader getReader();
}
