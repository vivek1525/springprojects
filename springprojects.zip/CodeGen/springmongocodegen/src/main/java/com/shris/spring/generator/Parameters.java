package com.shris.spring.generator;

import java.io.File;
import java.util.Map;

import com.shris.spring.generator.model.Entity;
import com.shris.spring.generator.model.GeneratorModel;

public class Parameters {

	String projectPath;
	String srcRoot;
	String resourcesRoot;
	String organization;
	String yamlPath;
	Map<String, Object> replacementParameters;
	String entity;
	GeneratorModel generatorModel;
	String packageName;
	String domainObject;
	String domainObjectCamelCase;
	String domainObjectCamel;
	Boolean enterpriseExist = true;
	Entity currentEntity;
	private boolean overrideExisting = false;
	

	public Parameters(GeneratorModel generatorModel) {
		this.generatorModel = generatorModel;
	}

	public String getEntity() {
		return domainObject;
	}

	public String getProjectPath() {
		return generatorModel.getApp().getServerProjectPath();
	}

	public String getSrcRoot() {
		return getProjectPath() + File.separator + "src" + File.separator + "main" + File.separator + "java";
	}

	public String getResourcesRoot() {
		return getProjectPath() + File.separator + "src" + File.separator + "main" + File.separator + "resources";
	}
	
	public String getTestRoot() {
		return getProjectPath() + File.separator + "src" + File.separator + "test" + File.separator + "java";
	}

	public String getOrganization() {
		return generatorModel.getApp().getClient().toLowerCase();
	}

	public String getYamlPath() {
		return yamlPath;
	}

	public String getPackageName() {
		return "com." + getOrganization();
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public Map<String, Object> getReplacementParameters() {
		return replacementParameters;
	}

	public String getDomainObject() {
		return domainObject;
	}

	public void setDomainObject(String domainObject) {
		this.domainObject = domainObject;
	}

	public String getDomainObjectCamelCase() {
		return domainObjectCamelCase;
	}

	public void setDomainObjectCamelCase(String domainObjectCamelCase) {
		this.domainObjectCamelCase = domainObjectCamelCase;
	}

	public String getDomainObjectCamel() {
		return domainObjectCamel;
	}

	public void setDomainObjectCamel(String domainObjectCamel) {
		this.domainObjectCamel = domainObjectCamel;
	}

	public Boolean getEnterpriseExist() {
		return enterpriseExist;
	}

	public void setEnterpriseExist(Boolean enterpriseExist) {
		this.enterpriseExist = enterpriseExist;
	}

	public Entity getCurrentEntity() {
		return currentEntity;
	}

	public void setCurrentEntity(Entity currentEntity) {
		this.currentEntity = currentEntity;
	}
	
	public boolean isOverrideExisting() {
		return overrideExisting;
	}

	public void setOverrideExisting(boolean overrideExisting) {
		this.overrideExisting = overrideExisting;
	}
	
}
