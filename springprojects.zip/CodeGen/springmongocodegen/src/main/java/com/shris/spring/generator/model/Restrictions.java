package com.shris.spring.generator.model;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.annotation.JsonRawValue;

public class Restrictions {
	
	private boolean disabled; //	Specifies that an input field should be disabled
	private int max; // Specifies the maximum value for an input field
	private int maxlength; //	Specifies the maximum number of character for an input field
	private int min = -1293; // Specifies the minimum value for an input field
	private String pattern; // Specifies a regular expression to check the input value against
	private boolean readonly; //Specifies that an input field is read only (cannot be changed)
	private boolean required; // Specifies that an input field is required (must be filled out)
	private int size; // Specifies the width (in characters) of an input field
	private int step; // Specifies the legal number intervals for an input field
	private boolean selected; // default selected
	private int rows; // Used with text area
	private int cols; // Used with text area
	private String stringValue;
	private boolean unique;
	
	public boolean getDisabled() {
		return disabled;
	}
	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}
	public boolean getSelected() {
		return selected;
	}
	public void setSelected(boolean selected) {
		this.selected = selected;
	}
	public int getMax() {
		return max;
	}
	public void setMax(int max) {
		this.max = max;
	}
	public int getMaxlength() {
		return maxlength;
	}
	public void setMaxlength(int maxlength) {
		this.maxlength = maxlength;
	}
	public int getMin() {
		return min;
	}
	public void setMin(int min) {
		this.min = min;
	}
	public String getPattern() {
		return pattern;
	}
	public void setPattern(String pattern) {
		this.pattern = pattern;
	}
	public boolean getReadonly() {
		return readonly;
	}
	public void setReadonly(boolean readonly) {
		this.readonly = readonly;
	}
	public boolean getRequired() {
		return required;
	}
	public void setRequired(boolean required) {
		this.required = required;
	}
	public int getSize() {
		return size;
	}
	public void setSize(int size) {
		this.size = size;
	}
	public int getStep() {
		return step;
	}
	public void setStep(int step) {
		this.step = step;
	}
	public int getRows() {
		return rows;
	}
	public void setRows(int rows) {
		this.rows = rows;
	}
	public int getCols() {
		return cols;
	}
	public void setCols(int cols) {
		this.cols = cols;
	}
	@JsonRawValue
	public String getStringValue() {
		
		final StringBuilder restrictions = new StringBuilder();
		final String SPACE = " ";
		
		if(!StringUtils.isEmpty(pattern)) {
			restrictions.append(SPACE).append("pattern=").append(pattern).append(SPACE);
		}
		
		if(maxlength > 0) {
			restrictions.append(SPACE).append("maxlength=").append(maxlength).append(SPACE);
		}
		
		if(size > 0) {
			restrictions.append(SPACE).append("size=").append(size).append(SPACE);
		}
		
		if(min != -1293) {
			restrictions.append(SPACE).append("min=").append(min).append(SPACE);
		}
		
		if(max > 0) {
			restrictions.append(SPACE).append("max=").append(max).append(SPACE);
		}
		
		if(step > 0) {
			restrictions.append(SPACE).append("step=").append(step).append(SPACE);
		}
		
		if(rows > 0) {
			restrictions.append(SPACE).append("rows=").append(rows).append(SPACE);
		}
		
		if(cols > 0) {
			restrictions.append(SPACE).append("cols=").append(cols).append(SPACE);
		}
		// -------------------------
		// KEEP THESE TO THE END
		// -------------------------
		if(this.disabled) {
			restrictions.append(SPACE).append("disabled").append(SPACE);
		}
		
		if(this.readonly) {
			restrictions.append(SPACE).append("readonly").append(SPACE);
		}
		
		if(this.required) {
			restrictions.append(SPACE).append("required").append(SPACE);
		}
		
		if(this.selected) {
			restrictions.append(SPACE).append("selected").append(SPACE);
		}
		this.stringValue =  restrictions.toString();
		return stringValue;
	}
	
	
	public boolean isUnique() {
		return unique;
	}
	public void setUnique(boolean unique) {
		this.unique = unique;
	}
	
	public boolean getIsRequired() {
		return required == true;
	}
	
	public boolean getIsUnique() {
		return unique == true;
	}
}
