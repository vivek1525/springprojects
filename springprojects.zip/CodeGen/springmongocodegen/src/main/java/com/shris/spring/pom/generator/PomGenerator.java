package com.shris.spring.pom.generator;

import java.io.File;

import com.shris.spring.generator.AbstractGenerator;
import com.shris.spring.generator.Parameters;
import com.shris.spring.generator.Template;

/**
 * 
 * Include most common dependencies
 */
public class PomGenerator extends AbstractGenerator{
	
	final PomTemplate pomTemplate = new PomTemplate();

	/** Name of the file to which content needs to be written */
	protected String getFileName(Parameters params) {
		
		final StringBuilder fileNameBuilder = new StringBuilder();
		fileNameBuilder.append(params.getProjectPath())
					   .append(File.separator)
					   .append("pom.xml");

		return fileNameBuilder.toString();
	}

	/** Template class from which content needs to be fetched. */
	protected Template getTemplate() {
		return pomTemplate;
	}
}