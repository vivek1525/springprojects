package com.shris.spring.repository.generator;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.shris.spring.generator.Parameters;
import com.shris.spring.generator.Template;

public class SpringRepositoryTemplate implements Template{
	
	private Parameters params;

	public SpringRepositoryTemplate() {}
	
	public SpringRepositoryTemplate(Parameters params) {
		this.params = params;
	}
	public Reader getReader() {
		
		String templateName = "RepositoryTemplate.mustache";
		
		if(params != null && params.getCurrentEntity() != null && params.getCurrentEntity().getSoftDelete()) {
			templateName = "SoftDeleteRepositoryTemplate.mustache";
		}
		
		final InputStream is = getClass().getClassLoader().getResourceAsStream(templateName);
		final BufferedReader br = new BufferedReader(new InputStreamReader(is));
		return br;
	}
	

}
