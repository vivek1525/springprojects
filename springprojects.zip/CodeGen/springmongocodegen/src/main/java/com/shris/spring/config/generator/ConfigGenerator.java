package com.shris.spring.config.generator;

import java.io.File;

import com.shris.spring.generator.AbstractGenerator;
import com.shris.spring.generator.Parameters;
import com.shris.spring.generator.Template;

/**
 * Generates profile specific to an environment.
 * 
 * Right profile is picked based on value of -Dspring.profiles.active
 * 
 * Ex: java -jar -Dspring.profiles.active=production sudrania-0.0.1-SNAPSHOT.jar 
 * 					would pick application-production.properties
 * 
 * Ex: java -jar -Dspring.profiles.active=uat sudrania-0.0.1-SNAPSHOT.jar 
 * 					would pick application-uat.properties
 */
public class ConfigGenerator extends AbstractGenerator{
	
	final ConfigTemplate propertiesTemplate;
	private String profile;
	
	public ConfigGenerator(final String profile) {
		this.profile = profile;
		propertiesTemplate = new ConfigTemplate(profile);
	}
	/** Name of the file to which content needs to be written */
	protected String getFileName(Parameters params) {
		
		final StringBuilder fileNameBuilder = new StringBuilder();
		fileNameBuilder.append(params.getResourcesRoot())
					   .append(File.separator)
					   .append("application-" + profile  + ".properties");

		return fileNameBuilder.toString();
	}

	/** Template class from which content needs to be fetched. */
	protected Template getTemplate() {
		return propertiesTemplate;
	}
}
