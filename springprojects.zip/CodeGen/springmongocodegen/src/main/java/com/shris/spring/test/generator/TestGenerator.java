package com.shris.spring.test.generator;

import java.io.File;

import com.shris.spring.generator.AbstractGenerator;
import com.shris.spring.generator.Parameters;
import com.shris.spring.generator.Template;

/**
 * 
 * Generates Tests
 */
public class TestGenerator extends AbstractGenerator{
	
	final TestTemplate template = new TestTemplate();
	
	@Override
	protected String getFileName(Parameters params) {
		final StringBuilder fileNameBuilder = new StringBuilder();
		fileNameBuilder.append(params.getTestRoot())
					   .append(File.separator)
					   .append("com")
					   .append(File.separator)
					   .append(params.getOrganization())
					   .append(File.separator)
					   .append("test")
					   .append(File.separator)
					   .append("controller")
					   .append(File.separator)
					   .append(params.getEntity())
					   .append("ControllerTest.java");

		return fileNameBuilder.toString();
	}
	
	@Override
	protected Template getTemplate() {
		return template;
	}
}
