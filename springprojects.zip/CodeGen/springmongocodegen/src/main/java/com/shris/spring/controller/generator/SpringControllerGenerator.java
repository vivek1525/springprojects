package com.shris.spring.controller.generator;

import java.io.File;

import com.shris.spring.generator.AbstractGenerator;
import com.shris.spring.generator.Parameters;
import com.shris.spring.generator.Template;

public class SpringControllerGenerator extends AbstractGenerator {

	final SpringControllerTemplate springControllerTemplate = new SpringControllerTemplate();

	/** Name of the file to which content needs to be written */
	protected String getFileName(Parameters params) {
		
		final StringBuilder fileNameBuilder = new StringBuilder();
		fileNameBuilder.append(params.getSrcRoot())
					   .append(File.separator)
					   .append("com")
					   .append(File.separator)
					   .append(params.getOrganization())
					   .append(File.separator)
					   .append("controller")
					   .append(File.separator)
					   .append(params.getEntity())
					   .append("Controller.java");

		return fileNameBuilder.toString();
	}

	/** Template class from which content needs to be fetched. */
	protected Template getTemplate() {
		return springControllerTemplate;
	}
}
