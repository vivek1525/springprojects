package com.shris.spring.domain.generator;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.shris.spring.generator.Template;

public class DomainObjectTemplate implements Template{
	

	public DomainObjectTemplate() {}
	
	
	public Reader getReader() {
		
		String templateName = "DomainTemplate.mustache";
		final InputStream is = getClass().getClassLoader().getResourceAsStream(templateName);
		final BufferedReader br = new BufferedReader(new InputStreamReader(is));
		return br;
	}
	

}
