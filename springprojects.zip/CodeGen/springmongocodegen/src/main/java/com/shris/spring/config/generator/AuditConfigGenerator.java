package com.shris.spring.config.generator;

import java.io.File;

import com.shris.spring.generator.AbstractGenerator;
import com.shris.spring.generator.Parameters;
import com.shris.spring.generator.Template;

public class AuditConfigGenerator extends AbstractGenerator {
	
	final AuditConfigTemplate auditConfigTemplate = new AuditConfigTemplate();

	/** Name of the file to which content needs to be written */
	protected String getFileName(Parameters params) {

		final StringBuilder fileNameBuilder = new StringBuilder();
		fileNameBuilder.append(params.getSrcRoot()).append(File.separator).append("com").append(File.separator)
				.append(params.getOrganization()).append(File.separator).append("config").append(File.separator)
				.append("AuditConfig.java");

		return fileNameBuilder.toString();
	}

	/** Template class from which content needs to be fetched. */
	protected Template getTemplate() {
		return auditConfigTemplate;
	}
}