package com.shris.spring.common.generator;

import java.io.File;

import com.shris.spring.generator.AbstractGenerator;
import com.shris.spring.generator.Parameters;
import com.shris.spring.generator.Template;


public class JSONUtilGenerator extends AbstractGenerator {

	final JSONUtilTemplate jsonUtilTemplate = new JSONUtilTemplate();

	/** Name of the file to which content needs to be written */
	protected String getFileName(Parameters params) {
		
		final StringBuilder fileNameBuilder = new StringBuilder();
		fileNameBuilder.append(params.getSrcRoot())
		   .append(File.separator)
		   .append("com")
		   .append(File.separator)
		   .append(params.getOrganization())
		   .append(File.separator)
		   .append("common")
		   .append(File.separator)
		   .append("JSONUtil.java");

		return fileNameBuilder.toString();
	}

	/** Template class from which content needs to be fetched. */
	protected Template getTemplate() {
		return jsonUtilTemplate;
	}
}