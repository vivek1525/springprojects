package com.shris.spring.config.generator;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.shris.spring.generator.Template;

public class ConfigTemplate implements Template{
	
	private String profile;

	public ConfigTemplate(final String profile) {
		this.profile = profile;
	}
	
	public Reader getReader() {
		final InputStream is = getClass().getClassLoader().getResourceAsStream("application-" + profile  + ".properties");
		final BufferedReader br = new BufferedReader(new InputStreamReader(is));
		return br;
	}
	
	public String getTemplate() {
		return null;
	}
}
