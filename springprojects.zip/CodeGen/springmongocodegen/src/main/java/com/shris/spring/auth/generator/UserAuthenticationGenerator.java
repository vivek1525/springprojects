package com.shris.spring.auth.generator;

import java.io.File;

import com.shris.spring.generator.Generator;
import com.shris.spring.generator.GenericGenerator;
import com.shris.spring.generator.Parameters;

/**
 * Generates skeleton for authentication and authorization
 * 
 */
public class UserAuthenticationGenerator implements Generator {

	public void generate(Parameters params) throws Exception {
		final  GenericGenerator genericGenerator = new GenericGenerator();

		final StringBuilder userAccountBuilder = new StringBuilder();

		userAccountBuilder.append(params.getSrcRoot())
							.append(File.separator).append("com")
							.append(File.separator)
							.append(params.getOrganization())
							.append(File.separator)
							.append("domain")
							.append(File.separator)
							.append("Account.java");
		// Generate Account class
		genericGenerator.setSourceFileName("Account.mustache")
						.setDestinationFilePath(userAccountBuilder.toString())
						.setParams(params)
						.generate();
		
		final StringBuilder accountRepositoryBuilder = new StringBuilder();

		accountRepositoryBuilder.append(params.getSrcRoot())
							.append(File.separator).append("com")
							.append(File.separator)
							.append(params.getOrganization())
							.append(File.separator)
							.append("repository")
							.append(File.separator)
							.append("AccountRepository.java");
		// Generate Account Repository class
		genericGenerator.setSourceFileName("AccountRepository.mustache")
						.setDestinationFilePath(accountRepositoryBuilder.toString())
						.setParams(params)
						.generate();
		
		final StringBuilder webSecurityConfigBuilder = new StringBuilder();

		webSecurityConfigBuilder.append(params.getSrcRoot())
							.append(File.separator).append("com")
							.append(File.separator)
							.append(params.getOrganization())
							.append(File.separator)
							.append("security")
							.append(File.separator)
							.append("WebSecurityConfiguration.java");
		// Generate WebSecurityConfiguration class
		genericGenerator.setSourceFileName("WebSecurityConfiguration.mustache")
						.setDestinationFilePath(webSecurityConfigBuilder.toString())
						.setParams(params)
						.generate();
		
		final StringBuilder clientUserBuilder = new StringBuilder();

		clientUserBuilder.append(params.getSrcRoot())
							.append(File.separator).append("com")
							.append(File.separator)
							.append(params.getOrganization())
							.append(File.separator)
							.append("security")
							.append(File.separator)
							.append("ClientUser.java");
		// Generate ClientUser class
		genericGenerator.setSourceFileName("ClientUser.mustache")
						.setDestinationFilePath(clientUserBuilder.toString())
						.setParams(params)
						.generate();
		
		final StringBuilder userPrincipalBuilder = new StringBuilder();

		userPrincipalBuilder.append(params.getSrcRoot())
							.append(File.separator).append("com")
							.append(File.separator)
							.append(params.getOrganization())
							.append(File.separator)
							.append("security")
							.append(File.separator)
							.append("UserPrincipal.java");
		// Generate UserPrincipal class
		genericGenerator.setSourceFileName("UserPrincipal.mustache")
						.setDestinationFilePath(userPrincipalBuilder.toString())
						.setParams(params)
						.generate();
		
		final StringBuilder mainControllerBuilder = new StringBuilder();

		mainControllerBuilder.append(params.getSrcRoot())
							.append(File.separator).append("com")
							.append(File.separator)
							.append(params.getOrganization())
							.append(File.separator)
							.append("controller")
							.append(File.separator)
							.append("MainController.java");
		// Generate UserPrincipal class
		genericGenerator.setSourceFileName("MainController.mustache")
						.setDestinationFilePath(mainControllerBuilder.toString())
						.setParams(params)
						.generate();
		final StringBuilder fileUploadBuilder = new StringBuilder();

		fileUploadBuilder.append(params.getSrcRoot())
							.append(File.separator).append("com")
							.append(File.separator)
							.append(params.getOrganization())
							.append(File.separator)
							.append("controller")
							.append(File.separator)
							.append("UploadFileController.java");
		// Generate UserPrincipal class
		genericGenerator.setSourceFileName("UploadFileController.mustache")
						.setDestinationFilePath(fileUploadBuilder.toString())
						.setParams(params)
						.generate();
		
		final StringBuilder applicationConstantsBuilder = new StringBuilder();

		applicationConstantsBuilder.append(params.getSrcRoot())
							.append(File.separator).append("com")
							.append(File.separator)
							.append(params.getOrganization())
							.append(File.separator)
							.append("constants")
							.append(File.separator)
							.append("AppConstants.java");
		// Generate UserPrincipal class
		genericGenerator.setSourceFileName("AppConstants.mustache")
						.setDestinationFilePath(applicationConstantsBuilder.toString())
						.setParams(params)
						.generate();
		
		final StringBuilder responseObjectBuilder = new StringBuilder();

		responseObjectBuilder.append(params.getSrcRoot())
							.append(File.separator).append("com")
							.append(File.separator)
							.append(params.getOrganization())
							.append(File.separator)
							.append("common")
							.append(File.separator)
							.append("ResponseObject.java");
		// Generate UserPrincipal class
		genericGenerator.setSourceFileName("ResponseObject.mustache")
						.setDestinationFilePath(responseObjectBuilder.toString())
						.setParams(params)
						.generate();
		
		
	}
}


