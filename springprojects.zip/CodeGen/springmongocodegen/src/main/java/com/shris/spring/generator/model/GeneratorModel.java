package com.shris.spring.generator.model;

/**
 * 
 * 
 * @author Shris Infotech
 *
 */
public class GeneratorModel {
	
	private App app;
	
	
	public App getApp() {
		return app;
	}

	public void setApp(App app) {
		this.app = app;
	}
	
}
