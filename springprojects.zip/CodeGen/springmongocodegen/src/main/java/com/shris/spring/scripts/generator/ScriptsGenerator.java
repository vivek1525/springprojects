package com.shris.spring.scripts.generator;

import java.io.File;

import com.shris.spring.generator.Generator;
import com.shris.spring.generator.GenericGenerator;
import com.shris.spring.generator.Parameters;

/**
 * Generates init and start scripts
 */
public class ScriptsGenerator implements Generator{

	public void generate(Parameters params) throws Exception {
		
		final  GenericGenerator genericGenerator = new GenericGenerator();

		StringBuilder fileNameBuilder = new StringBuilder();
		fileNameBuilder.append(params.getProjectPath())
					   .append(File.separator)
					   .append("init.bat");
		
		// Generate Account class
		genericGenerator.setSourceFileName("init.mustache")
						.setDestinationFilePath(fileNameBuilder.toString())
						.setParams(params)
						.generate();
		
		fileNameBuilder = new StringBuilder();
		fileNameBuilder.append(params.getProjectPath())
					   .append(File.separator)
					   .append("run.bat");
		
		// Generate Account class
		genericGenerator.setSourceFileName("run.mustache")
						.setDestinationFilePath(fileNameBuilder.toString())
						.setParams(params)
						.generate();
		
	}

}
