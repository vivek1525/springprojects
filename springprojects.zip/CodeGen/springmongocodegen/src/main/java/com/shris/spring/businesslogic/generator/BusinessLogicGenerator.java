package com.shris.spring.businesslogic.generator;

/**
 * Business Logic place holder generator
 */
public class BusinessLogicGenerator {

}
