package com.shris.spring.pom.generator;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.shris.spring.generator.Template;

public class PomTemplate implements Template{

	public Reader getReader() {
		final InputStream is = getClass().getClassLoader().getResourceAsStream("pom.xml");
		final BufferedReader br = new BufferedReader(new InputStreamReader(is));
		return br;
	}
	
	public String getTemplate() {
		return null;
	}
}
