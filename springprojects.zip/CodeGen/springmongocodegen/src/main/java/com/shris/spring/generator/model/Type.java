package com.shris.spring.generator.model;

public enum Type {
	ref, checkbox, color, date, datetimelocal, email, file, hidden, image, month, number, password, radio,
	range, reset, search, submit, tel, text, time, url, week, staticselect, select, lookupselect, combo,  multiSelect, string
}
