package com.shris.spring.generator;

import java.io.File;

import com.shris.spring.auth.generator.UserAuthenticationGenerator;
import com.shris.spring.bootapplication.generator.SpringBootApplicationGenerator;
import com.shris.spring.cache.generator.CacheGenerator;
import com.shris.spring.common.generator.GlobalControllerExceptionHandlerGenerator;
import com.shris.spring.common.generator.JSONUtilGenerator;
import com.shris.spring.common.generator.QueryFactoryGenerator;
import com.shris.spring.common.generator.QueryUtilGenerator;
import com.shris.spring.config.generator.AWSConfigGenerator;
import com.shris.spring.config.generator.AbstractAuditableEntityGenerator;
import com.shris.spring.config.generator.AuditConfigGenerator;
import com.shris.spring.config.generator.ConfigGenerator;
import com.shris.spring.controller.generator.SpringControllerGenerator;
import com.shris.spring.domain.generator.DomainObjectGenerator;
import com.shris.spring.dto.generator.ResultDtoGenerator;
import com.shris.spring.exception.generator.CascadeDeleteDependencyExceptionGenerator;
import com.shris.spring.exception.generator.ResourceNotFoundExceptionGenerator;
import com.shris.spring.generator.model.Entity;
import com.shris.spring.generator.model.GeneratorModel;
import com.shris.spring.pom.generator.PomGenerator;
import com.shris.spring.properties.generator.BannerGenerator;
import com.shris.spring.properties.generator.InternationalizationGenerator;
import com.shris.spring.properties.generator.PropertiesGenerator;
import com.shris.spring.repository.generator.SpringRepositoryGenerator;
import com.shris.spring.scripts.generator.ScriptsGenerator;
import com.shris.spring.service.generator.MailSenderGenericServiceGenerator;
import com.shris.spring.service.generator.S3ServiceGenerator;
import com.shris.spring.service.generator.SpringDataServiceGenerator;
import com.shris.spring.service.generator.SpringServiceGenerator;
import com.shris.spring.test.generator.TestGenerator;
import com.shris.spring.validator.generator.ValidatorGenerator;

public class Application {

	final static ResultDtoGenerator dtoGenerator = new ResultDtoGenerator();
	final static SpringRepositoryGenerator repositoryGenerator = new SpringRepositoryGenerator();
	final static SpringServiceGenerator serviceGenerator = new SpringServiceGenerator();
	final static SpringControllerGenerator controllerGenerator = new SpringControllerGenerator();
	final static PropertiesGenerator propertiesGenerator = new PropertiesGenerator();
	final static BannerGenerator bannerGenerator = new BannerGenerator();
	final static PomGenerator pomGenerator = new PomGenerator();
	final static SpringBootApplicationGenerator applicationGenerator = new SpringBootApplicationGenerator();
	final static JSONUtilGenerator jsonUtilGenerator = new JSONUtilGenerator();
	final static QueryUtilGenerator queryUtilGenerator = new QueryUtilGenerator();
	final static QueryFactoryGenerator queryFactoryGenerator = new QueryFactoryGenerator();
	final static CacheGenerator cacheGenerator = new CacheGenerator();
	final static ConfigGenerator qaConfigGenerator = new ConfigGenerator("qa");
	final static ConfigGenerator uatConfigGenerator = new ConfigGenerator("uat");
	final static ConfigGenerator productionConfigGenerator = new ConfigGenerator("production");
	final static InternationalizationGenerator i18nGenerator = new InternationalizationGenerator("");
	final static InternationalizationGenerator i18nGeneratorEng = new InternationalizationGenerator("_en");
	final static InternationalizationGenerator i18nGeneratorFrench = new InternationalizationGenerator("_fr");
	final static ValidatorGenerator validatorGenerator = new ValidatorGenerator();
	final static GenericGenerator genericGenerator = new GenericGenerator();
	final static UserAuthenticationGenerator userAuthenticationGenerator = new UserAuthenticationGenerator();
	final static ScriptsGenerator scriptsGenerator = new ScriptsGenerator();
	final static SpringDataServiceGenerator springDataServiceGenerator = new SpringDataServiceGenerator();
	final static GlobalControllerExceptionHandlerGenerator globalControllerExceptionHandlerGenerator = new GlobalControllerExceptionHandlerGenerator();
	final static MailSenderGenericServiceGenerator mailSenderGenericServiceGenerator = new MailSenderGenericServiceGenerator();
	final static S3ServiceGenerator s3ServiceGenerator = new S3ServiceGenerator();
	final static AWSConfigGenerator awsConfigGenerator = new AWSConfigGenerator();
	final static AuditConfigGenerator auditConfigGenerator = new AuditConfigGenerator();
	final static AbstractAuditableEntityGenerator abstractAuditableEntityGenerator = new AbstractAuditableEntityGenerator();
	final static DomainObjectGenerator domainObjectGenerator = new DomainObjectGenerator();
	final static CascadeDeleteDependencyExceptionGenerator cascadeExceptionGenerator = new CascadeDeleteDependencyExceptionGenerator();
	final static ResourceNotFoundExceptionGenerator resourceNotFoundExceptionGenerator = new ResourceNotFoundExceptionGenerator();
	final static TestGenerator testGenerator = new TestGenerator();
	
	public static void main(final String args[]) throws Exception {
		Application.run(args);
	}

	public static void run(final String args[]) throws Exception {

		GeneratorModel generatorModel = ModelParser.parse(args);
		Parameters params = new Parameters(generatorModel);
		generateOnce(params);
		for (Entity entity : generatorModel.getApp().getEntities()) {
			//if(entity.isOverrideExisting())
			//{
				params.setDomainObject(entity.getName());
				params.setDomainObjectCamelCase(entity.getNameCamel());
				params.setDomainObjectCamel(entity.getNameCamel().toUpperCase());
				// Set current entity
				params.setCurrentEntity(entity);
				params.setOverrideExisting(entity.isOverrideExisting());
				generate(params);
			//}
		}

		System.out.println();
		System.out.println("--------------------------");
		System.out.println("Start hacking now !!!!");
		System.out.println("--------------------------");
	}

	private static void generateOnce(Parameters params) throws Exception {
		params.setOverrideExisting(true);
		dtoGenerator.generate(params);
		propertiesGenerator.generate(params);
		bannerGenerator.generate(params);
		pomGenerator.generate(params);
		applicationGenerator.generate(params);
		userAuthenticationGenerator.generate(params);
		jsonUtilGenerator.generate(params);
		queryUtilGenerator.generate(params);
		queryFactoryGenerator.generate(params);
		cacheGenerator.generate(params);
		qaConfigGenerator.generate(params);
		uatConfigGenerator.generate(params);
		productionConfigGenerator.generate(params);
		i18nGenerator.generate(params);
		i18nGeneratorEng.generate(params);
		i18nGeneratorFrench.generate(params);
		scriptsGenerator.generate(params);
		globalControllerExceptionHandlerGenerator.generate(params);
		mailSenderGenericServiceGenerator.generate(params);
		s3ServiceGenerator.generate(params);
		awsConfigGenerator.generate(params);
		auditConfigGenerator.generate(params);
		abstractAuditableEntityGenerator.generate(params);
		cascadeExceptionGenerator.generate(params);
		resourceNotFoundExceptionGenerator.generate(params);
		final StringBuilder readmeFileBuilder = new StringBuilder();
		readmeFileBuilder.append(params.getProjectPath()).append(File.separator).append("README.md");
		// Generate README.md
		genericGenerator.setSourceFileName("README.md").setDestinationFilePath(readmeFileBuilder.toString())
				.setParams(params).generate();

		final StringBuilder contextFileNameBuilder = new StringBuilder();
		contextFileNameBuilder.append(params.getSrcRoot()).append(File.separator).append("com").append(File.separator)
				.append(params.getOrganization()).append(File.separator).append("businessobject").append(File.separator)
				.append("Context.java");
		// Generate Business Object
		genericGenerator.setSourceFileName("Context.mustache").setDestinationFilePath(contextFileNameBuilder.toString())
				.setParams(params).generate();
		
		generateCoreDomainModel(params);
		generateCoreAnnotations(params);
		generateAuditingAndCascadeInfra(params);
		generateCustomWriteConcernCofig(params);
		generateGenericValidator(params);
		generateGenericBusinessService(params);
		generateGenericDataService(params);
		generateCommonUtil(params);
		generateCheckStyle(params);
	}
	
	private static void generateCommonUtil(Parameters params) throws Exception {
		final StringBuilder commonUtiBuilder = new StringBuilder();
		commonUtiBuilder.append(params.getSrcRoot())
		.append(File.separator).append("com")
		.append(File.separator)
		.append(params.getOrganization())
		.append(File.separator)
		.append("common")
		.append(File.separator)
		.append("CommonUtil.java");
		
		// Generate Custom write concern config generator
		genericGenerator.setSourceFileName("CommonUtil.mustache")
						.setDestinationFilePath(commonUtiBuilder.toString())
						.setParams(params)
						.generate();
		
	}
	
	private static void generateCheckStyle(Parameters params) throws Exception {
		final StringBuilder checkStyleBuilder = new StringBuilder();
		checkStyleBuilder.append(params.getProjectPath())
		.append(File.separator)
		.append("checkstyle.xml");
		
		// Generate Custom write concern config generator
		genericGenerator.setSourceFileName("checkstyle.xml")
						.setDestinationFilePath(checkStyleBuilder.toString())
						.setParams(params)
						.generate();
		
	}
	private static void generateGenericDataService(Parameters params) throws Exception {
		final StringBuilder genericDataServiceBuilder = new StringBuilder();
		genericDataServiceBuilder.append(params.getSrcRoot())
		.append(File.separator).append("com")
		.append(File.separator)
		.append(params.getOrganization())
		.append(File.separator)
		.append("service")
		.append(File.separator)
		.append("GenericDataService.java");
		
		// Generate Custom write concern config generator
		genericGenerator.setSourceFileName("GenericDataService.mustache")
						.setDestinationFilePath(genericDataServiceBuilder.toString())
						.setParams(params)
						.generate();
		
	}

	private static void generateGenericBusinessService(Parameters params) throws Exception {
		final StringBuilder genericValidatorBuilder = new StringBuilder();
		genericValidatorBuilder.append(params.getSrcRoot())
		.append(File.separator).append("com")
		.append(File.separator)
		.append(params.getOrganization())
		.append(File.separator)
		.append("service")
		.append(File.separator)
		.append("GenericBusinessService.java");
		
		// Generate Custom write concern config generator
		genericGenerator.setSourceFileName("GenericBusinessService.mustache")
						.setDestinationFilePath(genericValidatorBuilder.toString())
						.setParams(params)
						.generate();
		
	}

	private static void generateGenericValidator(Parameters params) throws Exception {
		final StringBuilder genericValidatorBuilder = new StringBuilder();
		genericValidatorBuilder.append(params.getSrcRoot())
		.append(File.separator).append("com")
		.append(File.separator)
		.append(params.getOrganization())
		.append(File.separator)
		.append("validator")
		.append(File.separator)
		.append("GenericValidator.java");
		
		// Generate Custom write concern config generator
		genericGenerator.setSourceFileName("GenericValidatorTemplate.mustache")
						.setDestinationFilePath(genericValidatorBuilder.toString())
						.setParams(params)
						.generate();
		
	}

	private static void generateAuditingAndCascadeInfra(Parameters params) throws Exception {
		
		final StringBuilder cascadeInfraBuilder = new StringBuilder();
		cascadeInfraBuilder.append(params.getSrcRoot())
		.append(File.separator).append("com")
		.append(File.separator)
		.append(params.getOrganization())
		.append(File.separator)
		.append("event")
		.append(File.separator);
		
		// Generate CascadeCallback.java
		genericGenerator.setSourceFileName("CascadeCallback.mustache")
						.setDestinationFilePath(cascadeInfraBuilder.toString() + File.separator + "CascadeCallback.java")
						.setParams(params)
						.generate();
		
		// Generate FieldCallback.java
		genericGenerator.setSourceFileName("FieldCallback.mustache")
						.setDestinationFilePath(cascadeInfraBuilder.toString() + File.separator + "FieldCallback.java")
						.setParams(params)
						.generate();
		
		// Generate CascadeSaveMongoEventListener.java
		genericGenerator.setSourceFileName("CascadeSaveJpaEventListener.mustache")
						.setDestinationFilePath(cascadeInfraBuilder.toString() + File.separator + "CascadeSaveJpaEventListener.java")
						.setParams(params)
						.generate();
	}
	
	private static void generateCustomWriteConcernCofig(Parameters params) throws Exception {
		final StringBuilder customWriteConcernConfigBuilder = new StringBuilder();
		customWriteConcernConfigBuilder.append(params.getSrcRoot())
		.append(File.separator).append("com")
		.append(File.separator)
		.append(params.getOrganization())
		.append(File.separator)
		.append("config")
		.append(File.separator)
		.append("CustomWriteConcernResolver.java");
		
		// Generate Custom write concern config generator
		genericGenerator.setSourceFileName("CustomWriteConcernResolver.mustache")
						.setDestinationFilePath(customWriteConcernConfigBuilder.toString())
						.setParams(params)
						.generate();
		
	}
	
	private static void generateCoreAnnotations(Parameters params) throws Exception {
		final StringBuilder coreAnnotationsBuilder = new StringBuilder();
		coreAnnotationsBuilder.append(params.getSrcRoot())
		.append(File.separator).append("com")
		.append(File.separator)
		.append(params.getOrganization())
		.append(File.separator)
		.append("domain")
		.append(File.separator)
		.append("core")
		.append(File.separator)
		.append("annotation")
		.append(File.separator);
		
		// Generate Auditable annotation
		genericGenerator.setSourceFileName("Auditable.mustache")
						.setDestinationFilePath(coreAnnotationsBuilder.toString() + "Auditable.java")
						.setParams(params)
						.generate();
		
		// Generate CascadeSave annotation
		genericGenerator.setSourceFileName("CascadeSave.mustache")
						.setDestinationFilePath(coreAnnotationsBuilder.toString() + "CascadeSave.java")
						.setParams(params)
						.generate();
		
		// Enterprise Specific annotation
		genericGenerator.setSourceFileName("EnterpriseSpecific.mustache")
		.setDestinationFilePath(coreAnnotationsBuilder.toString() + "EnterpriseSpecific.java")
		.setParams(params)
		.generate();
		
		// SoftDelete annotation
		genericGenerator.setSourceFileName("SoftDelete.mustache")
		.setDestinationFilePath(coreAnnotationsBuilder.toString() + "SoftDelete.java")
		.setParams(params)
		.generate();
		
		
		// Required annotation
		genericGenerator.setSourceFileName("Required.mustache")
		.setDestinationFilePath(coreAnnotationsBuilder.toString() + "Required.java")
		.setParams(params)
		.generate();
		
		// Unique annotation
		genericGenerator.setSourceFileName("Unique.mustache")
		.setDestinationFilePath(coreAnnotationsBuilder.toString() + "Unique.java")
		.setParams(params)
		.generate();
		
		// UniqueFields  annotation
		genericGenerator.setSourceFileName("UniqueFields.mustache")
		.setDestinationFilePath(coreAnnotationsBuilder.toString() + "UniqueFields.java")
		.setParams(params)
		.generate();
		
		// UniqueFields  annotation
		genericGenerator.setSourceFileName("RequiredWhen.mustache")
		.setDestinationFilePath(coreAnnotationsBuilder.toString() + "RequiredWhen.java")
		.setParams(params)
		.generate();
	}

	private static void generateCoreDomainModel(Parameters params) throws Exception {
		
		final StringBuilder coreDomainObjectsBuilder = new StringBuilder();
		coreDomainObjectsBuilder.append(params.getSrcRoot())
		.append(File.separator).append("com")
		.append(File.separator)
		.append(params.getOrganization())
		.append(File.separator)
		.append("domain")
		.append(File.separator)
		.append("core")
		.append(File.separator);
		// Generate base domain objects.
		// Generate Enterprise
		genericGenerator.setSourceFileName("Enterprise.mustache")
						.setDestinationFilePath(coreDomainObjectsBuilder.toString() + "Enterprise.java")
						.setParams(params)
						.generate();
		
		// Generate Module
		genericGenerator.setSourceFileName("Module.mustache")
						.setDestinationFilePath(coreDomainObjectsBuilder.toString() +  "Module.java")
						.setParams(params)
						.generate();
		
		// Generate Module
		genericGenerator.setSourceFileName("Function.mustache")
						.setDestinationFilePath(coreDomainObjectsBuilder.toString() + "Function.java")
						.setParams(params)
						.generate();
				
		// Generate Role
		genericGenerator.setSourceFileName("Role.mustache")
						.setDestinationFilePath(coreDomainObjectsBuilder.toString() + "Role.java")
						.setParams(params)
						.generate();
		
		
		// Generate Base Domain
		genericGenerator.setSourceFileName("BaseDomain.mustache")
						.setDestinationFilePath(coreDomainObjectsBuilder.toString() + "BaseDomain.java")
						.setParams(params)
						.generate();
		
		// Generate Base Domain
		genericGenerator.setSourceFileName("SoftDeleteBaseDomain.mustache")
						.setDestinationFilePath(coreDomainObjectsBuilder.toString() + "SoftDeleteBaseDomain.java")
						.setParams(params)
						.generate();
		
		// Generate User Category
		genericGenerator.setSourceFileName("UserCategory.mustache")
						.setDestinationFilePath(coreDomainObjectsBuilder.toString() + "UserCategory.java")
						.setParams(params)
						.generate();
		
		// Generate AuditLog
		genericGenerator.setSourceFileName("AuditLog.mustache")
						.setDestinationFilePath(coreDomainObjectsBuilder.toString() + "AuditLog.java")
						.setParams(params)
						.generate();
		
		// Generate Operator enum
		genericGenerator.setSourceFileName("Operator.mustache")
						.setDestinationFilePath(coreDomainObjectsBuilder.toString() + "Operator.java")
						.setParams(params)
						.generate();
		
		// KeyValueFieldMarker annotation
		genericGenerator.setSourceFileName("KeyValueFieldMarker.mustache")
		.setDestinationFilePath(coreDomainObjectsBuilder.toString() + "KeyValueFieldMarker.java")
		.setParams(params)
		.generate();
	}
	
	private static void generate(Parameters params) throws Exception {
		generateDomainObject(params);
		repositoryGenerator.generate(params);
		serviceGenerator.generate(params);
		springDataServiceGenerator.generate(params);
		controllerGenerator.generate(params);
		validatorGenerator.generate(params);
		final StringBuilder businessObjectFileNameBuilder = new StringBuilder();
		businessObjectFileNameBuilder.append(params.getSrcRoot()).append(File.separator).append("com")
				.append(File.separator).append(params.getOrganization()).append(File.separator).append("businessobject")
				.append(File.separator).append(params.getEntity()).append("BusinessLogic.java");
		// Generate Business Object
		genericGenerator.setSourceFileName("BusinessObjectTemplate.mustache")
				.setDestinationFilePath(businessObjectFileNameBuilder.toString()).setParams(params).generate();
		// Generate Data Enricher
		final StringBuilder dataEnricherFileNameBuilder = new StringBuilder();
		dataEnricherFileNameBuilder.append(params.getSrcRoot()).append(File.separator).append("com")
				.append(File.separator).append(params.getOrganization()).append(File.separator).append("businessobject")
				.append(File.separator).append(params.getEntity()).append("DataEnricher.java");
		genericGenerator.setSourceFileName("DataEnricher.mustache")
				.setDestinationFilePath(dataEnricherFileNameBuilder.toString()).setParams(params).generate();
		// Generate tests
		testGenerator.generate(params);
	}
	
	private static void generateDomainObject(Parameters params) throws Exception {
		domainObjectGenerator.generate(params);
	}
}