package com.shris.spring.properties.generator;

import java.io.File;

import com.shris.spring.generator.AbstractGenerator;
import com.shris.spring.generator.Parameters;
import com.shris.spring.generator.Template;

public class FunctionFileGenerator extends AbstractGenerator{
	
	final FunctionFileTemplate template = new FunctionFileTemplate();
	
	/** Name of the file to which content needs to be written */
	protected String getFileName(Parameters params) {
		
		final StringBuilder fileNameBuilder = new StringBuilder();
		fileNameBuilder.append(params.getResourcesRoot())
					   .append(File.separator)
					   .append("file")
					   .append(File.separator)
					   .append("defaultfunctions.txt");

		return fileNameBuilder.toString();
	}

	/** Template class from which content needs to be fetched. */
	protected Template getTemplate() {
		return template;
	}
}