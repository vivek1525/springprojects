package com.shris.spring.exception.generator;

import java.io.File;

import com.shris.spring.generator.AbstractGenerator;
import com.shris.spring.generator.Parameters;
import com.shris.spring.generator.Template;

public class CascadeDeleteDependencyExceptionGenerator  extends AbstractGenerator{
	private CascadeDeleteDependencyExceptionTemplate exceptionTemplate = new CascadeDeleteDependencyExceptionTemplate();
	/** Name of the file to which content needs to be written */
	protected String getFileName(Parameters params) {
		
		final StringBuilder fileNameBuilder = new StringBuilder();
		fileNameBuilder.append(params.getSrcRoot())
					   .append(File.separator)
					   .append("com")
					   .append(File.separator)
					   .append(params.getOrganization())
					   .append(File.separator)
					   .append("exception")
					   .append(File.separator)
					   .append("CascadeDeleteDependencyException.java");
		

		return fileNameBuilder.toString();
	}

	/** Template class from which content needs to be fetched. */
	protected Template getTemplate() {
		return exceptionTemplate;
	}

}
