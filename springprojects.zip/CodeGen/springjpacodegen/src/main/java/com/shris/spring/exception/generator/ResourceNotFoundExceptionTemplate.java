package com.shris.spring.exception.generator;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import com.shris.spring.generator.Template;

public class ResourceNotFoundExceptionTemplate implements Template{
	

	public ResourceNotFoundExceptionTemplate() {}
	
	
	public Reader getReader() {
		
		String templateName = "ResourceNotFoundException.mustache";
		final InputStream is = getClass().getClassLoader().getResourceAsStream(templateName);
		final BufferedReader br = new BufferedReader(new InputStreamReader(is));
		return br;
	}
}