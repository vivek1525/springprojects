package com.shris.spring.dto.generator;

import java.io.File;

import com.shris.spring.generator.AbstractGenerator;
import com.shris.spring.generator.Parameters;
import com.shris.spring.generator.Template;

public class UserDtoGenerator extends AbstractGenerator {

	final UserDtoTemplate resultDtoTemplate = new UserDtoTemplate();

	/** Name of the file to which content needs to be written */
	protected String getFileName(Parameters params) {

		final StringBuilder fileNameBuilder = new StringBuilder();
		fileNameBuilder.append(params.getSrcRoot()).append(File.separator).append("com").append(File.separator)
				.append(params.getOrganization()).append(File.separator).append("dto").append(File.separator)
				.append("UserDto.java");

		return fileNameBuilder.toString();
	}

	/** Template class from which content needs to be fetched. */
	protected Template getTemplate() {
		return resultDtoTemplate;
	}
}
