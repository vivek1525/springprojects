package com.test.bootjpaclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootjpaclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
