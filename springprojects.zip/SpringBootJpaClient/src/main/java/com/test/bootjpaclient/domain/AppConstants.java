package com.test.bootjpaclient.domain;

public interface AppConstants {
	
	public static final String END_URL = "http://localhost:8080/";

}
