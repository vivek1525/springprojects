package com.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

public class HashMapWithListOfValues {

	int empid;
	String name;
	Character grade;

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Character getGrade() {
		return grade;
	}

	public void setGrade(Character grade) {
		this.grade = grade;
	}

	public HashMapWithListOfValues(int empid, String name, Character grade) {
		this.empid = empid;
		this.name = name;
		this.grade = grade;
	}

	@Override
	public String toString() {
		return "empid=" + empid + ", name=" + name + ", grade=" + grade;
	}

	public static void main(String[] args) {

		List<HashMapWithListOfValues> list = Arrays.asList(new HashMapWithListOfValues(1, "vivek", 'B'), new HashMapWithListOfValues(2, "mahesh", 'C'),
				new HashMapWithListOfValues(2, "sampath", 'A'), new HashMapWithListOfValues(4, "naresh", 'B'), new HashMapWithListOfValues(5, "shashi", 'A'));
		HashMap<Character, List<HashMapWithListOfValues>> testMap = new HashMap<>();

		for (HashMapWithListOfValues t : list) {
			List<HashMapWithListOfValues> list1 = testMap.get(t.getGrade());
			if (list1 == null || list1.isEmpty()) {
				list1 = new ArrayList<>();
			}
			list1.add(t);
			testMap.put(t.getGrade(), list1);
		}
		System.out.println(testMap);
	}

}
