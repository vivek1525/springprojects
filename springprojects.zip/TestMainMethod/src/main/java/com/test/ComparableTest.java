package com.test;

import java.util.ArrayList;
import java.util.Collections;

public class ComparableTest implements Comparable<ComparableTest> {

	int rollno;
	String name;
	int age;

	public ComparableTest(int rollno, String name, int age) {
		this.rollno = rollno;
		this.name = name;
		this.age = age;
	}

	public static void main(String[] args) {
		ArrayList<ComparableTest> al = new ArrayList<ComparableTest>();
		al.add(new ComparableTest(101, "Vijay", 23));
		al.add(new ComparableTest(106, "Ajay", 27));
		al.add(new ComparableTest(105, "Jai", 21));

		Collections.sort(al);
		for (ComparableTest st : al) {
			System.out.println(st.rollno + " " + st.name + " " + st.age);
		}

	}

	@Override
	public int compareTo(ComparableTest st) {
		if (age == st.age)
			return 0;
		else if (age > st.age)
			return 1;
		else
			return -1;
	}

	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}
