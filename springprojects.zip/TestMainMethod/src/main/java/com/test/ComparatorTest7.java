package com.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ComparatorTest7{

	int rollno;
	String name;
	int age;

	public ComparatorTest7(int rollno, String name, int age) {
		this.rollno = rollno;
		this.name = name;
		this.age = age;
	}

	public static void main(String[] args) {
		ArrayList<ComparatorTest7> al = new ArrayList<ComparatorTest7>();
		al.add(new ComparatorTest7(101, "Vijay", 23));
		al.add(new ComparatorTest7(106, "Ajay", 27));
		al.add(new ComparatorTest7(105, "Jai", 21));

		System.out.println("Sorting by Name");  
		Collections.sort(al,new Comparator<ComparatorTest7>() {

			@Override
			public int compare(ComparatorTest7 o1, ComparatorTest7 o2) {
				return o1.name.compareTo(o2.name);
			}
		});
		for (ComparatorTest7 st : al) {
			System.out.println(st.rollno + " " + st.name + " " + st.age);
		}
		
		System.out.println("Sorting by Age");  
		Collections.sort(al,new Comparator<ComparatorTest7>() {

			@Override
			public int compare(ComparatorTest7 s1, ComparatorTest7 s2) {
				if(s1.age==s2.age)  
					return 0;  
					else if(s1.age>s2.age)  
					return 1;  
					else  
					return -1;  
			}
		});
		for (ComparatorTest7 st : al) {
			System.out.println(st.rollno + " " + st.name + " " + st.age);
		}

	}

	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}
