package com.test;

public class Test {

	void checkAge(int age) throws ArithmeticException {
		if (age < 18)
			throw new ArithmeticException("Not Eligible for voting");
		else
			System.out.println("Eligible for voting");
	}

	int div(int a, int b) throws ArithmeticException {
		int t = a / b;
		System.out.println("div " + t);
		return t;
	}

	public static void main(String args[]){
		Test obj = new Test();
		try {
			System.out.println(obj.div(15, 2));
		} catch (Exception e) {
			System.out.println("arith exec");
		}
		try {
			obj.checkAge(16);
		} catch (Exception e) {
			System.out.println("Not Eligible for voting throw in main");
		}
		System.out.println("hello");
	}
}
