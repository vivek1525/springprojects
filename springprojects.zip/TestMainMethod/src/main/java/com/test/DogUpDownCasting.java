package com.test;

class Animal {
}

public class DogUpDownCasting extends Animal {

	public static void main(String[] args) {
		Animal a = new DogUpDownCasting(); // upcasting
		System.out.println("a object is " + a);
		DogUpDownCasting.method(a);

	}

	private static void method(Animal a) {

		if (a instanceof DogUpDownCasting) {
			DogUpDownCasting d = (DogUpDownCasting) a; // downcasting
			System.out.println("d object is " + d);
			System.out.println("ok downcasting performed");
		}
	}

}
