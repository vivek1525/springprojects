package com.test;

import java.util.Arrays;
import java.util.List;

interface Messageable {
	Message getMessage(String msg);
}

class Message {
	Message(String msg) {
		System.out.print(msg);
	}
}

public class MethodReference {

	interface Sayable {
		void say();
	}
	
	interface Ref {
		String msg(String msg);
	}


	public static void statictest() {
		System.out.println("static method reference test");
	}

	public void instancetest() {
		System.out.println("instance method reference test");
	}

	public static void main(String[] args) {

		List<String> names = Arrays.asList("vivek", "vikas", "shashi", "naresh");
		names.forEach(System.out::println); // method reference
		names.forEach(n -> System.out.println(n)); // Lamda Expression

		Sayable sayable = MethodReference::statictest; // static method reference
		sayable.say();
		
		MethodReference mr = new MethodReference();
		Sayable sayable2 = mr::instancetest; // instance method reference
		sayable2.say();
		
		Ref ref1 = (msg)-> msg;
		System.out.println("hi "+ref1.msg("Test"));  //lamda with functional interface

		Messageable msg = Message::new; // construcstor reference
		msg.getMessage("hello this is construcstor reference");

	}

}
