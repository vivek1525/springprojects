package com.test;

public class Test5<T> {

	private T t;

	public T getT() {
		return t;
	}

	public void setT(T t) {
		this.t = t;
	}

	public static void main(String[] args) {
		Test5 obj = new Test5();
		obj.setT("demo");
		obj.setT(10);
		obj.setT("%");
		System.out.println(obj.getT());

	}

}
