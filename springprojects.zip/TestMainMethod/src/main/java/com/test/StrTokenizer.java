package com.test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.StringTokenizer;
import java.util.stream.Collectors;

public class StrTokenizer {

	static String str = "vivek,reddy,korepu";

	public static void main(String[] args) {

		// StringTokenizer tokenizer = new StringTokenizer(str,",");
		/*
		 * while(tokenizer.hasMoreElements()) {
		 * System.out.println(tokenizer.nextElement()); }
		 */
		/*
		 * while(tokenizer.hasMoreTokens()) { System.out.println(tokenizer.nextToken());
		 * }
		 */
		List<Object> tokens = Collections.list(new StringTokenizer(str, ","));
		tokens.stream().forEach(token->System.out.println(token));
		tokens.stream().map(token -> (String) token).collect(Collectors.toList());
		System.out.println(tokens);
	}

}
