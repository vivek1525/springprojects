package com.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListImmutable {

	private static List<String> addressList = new ArrayList<>();

	public ListImmutable(List<String> addressList) {
		this.addressList = addressList;
	}

	@Override
	public String toString() {
		return "ListImmutable [addressList=" + addressList + "]";
	}

	public List<String> getAddressList() {
		return Collections.unmodifiableList(addressList);
	}

	public static void main(String[] args) {
		addressList.add("alwal");
		addressList.add("bolarum");
		ListImmutable lim2 = new ListImmutable(addressList);
		System.out.println(lim2.getAddressList());
		lim2.getAddressList().add("kompally");
		System.out.println(lim2);
	}
}
