package com.test;

import java.util.ArrayList;
import java.util.Collections;

public class ComparatorTest8 {

	int rollno;
	String name;
	int age;

	public ComparatorTest8(int rollno, String name, int age) {
		this.rollno = rollno;
		this.name = name;
		this.age = age;
	}

	public static void main(String[] args) {
		ArrayList<ComparatorTest8> al = new ArrayList<ComparatorTest8>();
		al.add(new ComparatorTest8(101, "Vijay", 23));
		al.add(new ComparatorTest8(106, "Ajay", 27));
		al.add(new ComparatorTest8(105, "Jai", 21));

		System.out.println("Sorting by Name");
		Collections.sort(al, (o1, o2) -> o1.name.compareTo(o2.name));
		for (ComparatorTest8 st : al) {
			System.out.println(st.rollno + " " + st.name + " " + st.age);
		}

		System.out.println("Sorting by Age");
		Collections.sort(al, (o1, o2) -> o1.age - o2.age);
		al.forEach(st -> System.out.println(st.rollno + " " + st.name + " " + st.age));

	}

	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}
