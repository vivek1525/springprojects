package com.test;

public class VowelCounter {

	public static void main(String[] args) {
		String s = "How many vowels in this String";

		char[] letters = s.toCharArray();
		int count = 0;
		for (char c : letters) {
			switch (c) {
			case 'a':
			case 'e':
			case 'i':
			case 'o':
			case 'u':
				count++;
				break;
			default:
				// no count increment
			}
		}
		System.out.println("Number of vowels in String [" + s + "] is : " + count);
	}
}
