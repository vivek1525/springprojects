package com.test;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class StreamsSort {

	public static void main(String[] args) {

		List<String> names1 = Arrays.asList("Mahesh", "Suresh", "Ramesh", "Naresh", "Kalpesh");
		List<String> names2 = Arrays.asList("Mahesh", "Suresh", "Ramesh", "Naresh", "Kalpesh");
		List<String> names3 = Arrays.asList("Mahesh", "Suresh", "Ramesh", "Naresh", "Kalpesh");

		StreamsSort tester = new StreamsSort();
		System.out.println("Sort using Java 7 syntax: ");
		tester.sortUsingJava7(names1);
		System.out.println(names1);

		System.out.println("Sort using Java 8 syntax: "); 
		tester.sortUsingJava8(names2);
		System.out.println(names2);

		List<String> output = names3.stream().sorted().collect(Collectors.toList());  //Using Stream
		System.out.println("output " + output);
	}

	// sort using java 7
	private void sortUsingJava7(List<String> names) {
		Collections.sort(names, new Comparator<String>() {
			@Override
			public int compare(String s1, String s2) {
				return s1.compareTo(s2);
			}
		});
	}

	//sort using java 8
	private void sortUsingJava8(List<String> names) {
		Collections.sort(names, (s1, s2) -> s1.compareTo(s2));  //Using Lamda Expression
	}

}
