package com.test;

public class FuncationalInterface {

	public static void main(String[] args) {

	}

}
