package com.test;

public class CaptializeEachWrdFstLetter {

	public static void main(String[] args) {

		String s = "hello world";
        String s1[]=s.split("\\s");
        String capitalizeWord="";  
        for(String w:s1) {
        	System.out.println(w);
        	String first=w.substring(0,1);
        	System.out.println(first);
        	String afterfirst=w.substring(1);
        	System.out.println(afterfirst);
        	capitalizeWord+=first.toUpperCase()+afterfirst+" ";
        	System.out.println(capitalizeWord);
        }
	}

}
