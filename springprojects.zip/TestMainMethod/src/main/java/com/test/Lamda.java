package com.test;

public class Lamda {

	public static void main(String args[]) {
		Lamda tester = new Lamda();

		// with type declaration
		MathOperation addition = (int a, int b) -> a + b; // Funcational Interfaces
		System.out.println("new "+addition.operation(10, 5));

		// with out type declaration
		MathOperation subtraction = (a, b) -> a - b;
		
		// with return statement along with curly braces
		MathOperation multiplication = (int a, int b) -> {
			return a * b;
		};

		// without return statement and without curly braces
		MathOperation division = (int a, int b) -> a / b;

		System.out.println("10 + 5 = " + tester.operate(10, 5, addition));
		System.out.println("10 - 5 = " + tester.operate(10, 5, subtraction));
		System.out.println("10 x 5 = " + tester.operate(10, 5, multiplication));
		System.out.println("10 / 5 = " + tester.operate(10, 5, division));

		// without parenthesis
		GreetingService greetService1 = message -> System.out.println("Hello " + message);

		// with parenthesis
		GreetingService greetService2 = (message) -> System.out.println("Hello " + message);

		greetService1.sayMessage("Mahesh");
		greetService2.sayMessage("Suresh");
		
		HelloService hs = ()->System.out.println("hello lamda");  //Using Lamda
		hs.sayMessage();
		
		HelloService hs1 = tester::test;                          //Using Method Reference
		hs1.sayMessage();

	}

	interface MathOperation {
		int operation(int a, int b);
	}

	interface GreetingService {
		void sayMessage(String message);
	}
	
	interface HelloService {
		void sayMessage();
	}
	
	 public void test() {
	  System.out.println("hello hi");
	}

	private int operate(int a, int b, MathOperation mathOperation) {
		return mathOperation.operation(a, b);
	}

}
