package com.test;

public interface TestInf {
	 double add(int a,int b, double c);

}
