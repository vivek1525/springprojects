package com.test;

import java.util.Arrays;

public class TestAnagram {
	public static boolean iAnagram(String word, String anagram) {
		char[] charFromWord = word.toCharArray();
		char[] charFromAnagram = anagram.toCharArray();
		Arrays.sort(charFromWord);
		Arrays.sort(charFromAnagram);
		return Arrays.equals(charFromWord, charFromAnagram);
	}
	
	public static void main(String[] args) {
		
		TestAnagram ta = new TestAnagram();
		System.out.println(ta.iAnagram("vivek", "ievkv"));
	}

}
