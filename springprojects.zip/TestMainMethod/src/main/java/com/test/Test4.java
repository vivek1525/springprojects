package com.test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Test4 {

	public static void main(String[] args) {

		List<String> str = Arrays.asList("Hello", "Hai", "vivek");
		Map<Character, Integer> out = new HashMap();
		for (String val : str) {

			for (char c : val.toCharArray()) {
				if (out.containsKey(c)) {
					out.put(c, out.get(c) + 1);
				} else {
					out.put(c, 1);
				}
			}
		}
		System.out.println("output " + out);

	}

}
