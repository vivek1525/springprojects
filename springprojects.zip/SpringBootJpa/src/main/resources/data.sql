insert into user values (101,27,'vivek.korepu@gmail.com','Y','vivek');
insert into user values(102,24,'vikas1603@gmail.com','N','vikas');
insert into user values(103,50,'raju@gmail.com','Y','raju');
insert into user values(104,42,'laxmi@gmail.com','N','laxmi');
insert into user values(105,65,'prathap@gmail.com','Y','prathap');
insert into user values(106,40,'venkat@gmail.com','N','venkat');
