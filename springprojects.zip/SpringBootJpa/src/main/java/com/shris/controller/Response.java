package com.shris.controller;

public class Response<T1, T2> {

}
