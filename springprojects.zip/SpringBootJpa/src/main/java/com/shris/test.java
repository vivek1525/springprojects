package com.shris;

import java.util.HashMap;
import java.util.Set;

public class test {
	public static int CostString(int N, String S, String R) {

		int freq1 = freqCalc(S);
		int freq2 = freqCalc(R);
		int result = Max(freq1, freq2);
		return result;
	}

	private static int freqCalc(String str) {
		HashMap<Character, Integer> charFreqMap = new HashMap<Character, Integer>();
		for (int i = 0; i < str.length(); i++) {
			Character ch = str.charAt(i);
			if (charFreqMap.containsKey(ch)) {
				int count = charFreqMap.get(ch);
				charFreqMap.put(ch, count + 1);
			} else {
				charFreqMap.put(ch, 1);
			}
		}
		Set<Character> keys = charFreqMap.keySet();
		System.out.println(keys);
		int k = 0;
		for (char key : keys) {
			if (charFreqMap.get(key) > 1) {
				int S1 = charFreqMap.get(key) * 2;
				k = k + S1;
			}
		}
		return k;
	}

	private static int Max(int i, int j) {
		if (i < j) {
			return j;
		}
		return i;
	}

	public static void main(String[] args) {
		System.out.print(CostString(6, "aabccd", "ddeeea"));
	}
}
